#include"stdafx.h"
#include "GlobalVars.h"
#include <fstream>