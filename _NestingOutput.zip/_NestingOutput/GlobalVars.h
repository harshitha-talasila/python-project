#pragma once
#include "StdAfx.h"
#include <iostream>
#include <string>
#include <vector>
#include <OdaCommon.h>
#include "RxObjectImpl.h"
#include <DbEntity.h>
#include <DbAttribute.h>
#include <DbAttributeDefinition.h>
#include <DbTextStyleTable.h>
#include <DbTextStyleTableRecord.h>
#include <DbSymbolTable.h>
#include <DbLayerTable.h>
#include <DbLayerTableRecord.h>
#include <DbLinetypeTable.h>
#include <DbLinetypeTableRecord.h>
#include <DbObjectContextManager.h>
#include <DbObjectContextCollection.h>
#include <DbAnnotativeObjectPE.h>
#include <DbAnnotationScale.h>
#include "..\..\inc\ArxCompat.h"


using namespace std;
using std::vector;

class ActGlobalVariables
{
public:
	std::vector<CString> vUtVals;
	std::vector<CString> vSnVals;
	std::vector<CString> g_nestedQtyValues;
	void Empty() 
	{
		this->~ActGlobalVariables();
		new (this) ActGlobalVariables();
	}
};

extern ActGlobalVariables cGV;


