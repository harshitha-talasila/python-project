// IRXSample.h : main header file for the IRXSample DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols


// CIRXSampleApp
// See IRXSample.cpp for the implementation of this class
//

class CIRXSampleApp : public CWinApp
{
public:
	CIRXSampleApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
