#include "StdAfx.h"
#include "OdaCommon.h"
#include "afxtoolbar.h"
#include "RxObjectImpl.h"
#include "DbBlockTableRecord.h"
#include "DbText.h"
#include "DbDictionary.h"
#include "DbCircle.h"
#include "DbGroup.h"
#include "DbSymUtl.h"
#include "DbBlockTable.h"
#include "DbViewportTable.h"
#include "DbViewport.h"
#include "DbLayerTable.h"
#include "DbAbstractViewTableRecord.h"
#include "DbVisualStyle.h"
#include "DbLayerTableRecord.h"
#include "DbSymUtl.h"
#include "../../inc/ArxCompat.h"
#include "DbRegAppTable.h"
#include "DbRegAppTableRecord.h"
#include "DbCommandContext.h"
#include "DbLinetypeTableRecord.h"
#include "Db3dPolyline.h"
#include "DbAlignedDimension.h"
#include "DbRotatedDimension.h"
#include "Db3dPolylineVertex.h"
#include "DbRadialDimensionLarge.h"
#include "DbRadialDimension.h"
#include "Db3PointAngularDimension.h"
#include"DbLeader.h"
#include "StringArray.h"
#include "DbEvalGraph.h"
#include"Dbtext.h"

#include "IRXSampleModule.h"
#include "IrxSampleDialog.h"
#include "IRXPreviewDialog.h"
#include "IcApi.h"
#include "windows.h"

#include "IcApDocManager.h"
#include "IcApDocumentIterator.h"
#include "IcApDocument.h"
#include "IcEdInputPointManager.h"
#include "IcadDbHostApplicationServices.h"
#include "IcGs.h"
#include "icedsds.h"



#include "IcColorSettings.h"

#include "sds.h"

#include "StaticRxObject.h"
#include "DbPolyline.h"
#include "DbSpLine.h"
#include "DbArc.h"


#include "Gi/GiDrawableImpl.h"
#include "Gi/GiWorldDraw.h"
#include "Gi/GiViewportDraw.h"

#include "Ge/GeExtents2d.h"
#include "DbUserIO.h"

#include "MultipleEntitiesJig.h"
#include "Db3dPolyline.h"
#include "cmath"
#include "windows.h"

#include "ios"
#include "iostream"
#include "fstream"
#include "sstream"

#include "OdaCommon.h"
#include "RxObject.h"
#include "DbBaseDatabase.h"
#include "DbDictionary.h"
#include "DbObjectIterator.h"
#include "DbText.h"
#include"Dbfcf.h"
#include"cmath"
#include"iomanip"
#include"DbPoint.h"
#include"OdString.h"
#include <string.h>
#include <filesystem>
#include<regex>

using namespace std;

ODRX_DEFINE_DYNAMIC_MODULE(IRXSampleModule);
typedef void (*OdEdCommandFn)(OdEdCommandContext* pCmdCtx);

extern void NESTOUTPUT(OdEdCommandContext* pCmdCtx);

class CommandImpl : public OdEdCommand
{
	OdEdCommandFn m_execute;
	OdString m_szCmdGroup;
	OdString m_szGlobalName;
    OdString m_szLocalName;
public:
	void execute(OdEdCommandContext* pCmdCtx) { m_execute(pCmdCtx); }
	const OdString globalName() const { return m_szGlobalName; }
	const OdString localName() const { return m_szGlobalName; }
	const OdString groupName() const { return m_szCmdGroup; }

	static OdEdCommandPtr createWrapper(OdEdCommandFn executeFn,
		const OdChar* szCmdGroup,
		const OdChar* szGlobalName)
	{
		OdSmartPtr<OdEdCommand> pRes = OdEdCommand::createObject(szCmdGroup, szGlobalName, szGlobalName, kUsePickset, executeFn, 0);
		return pRes;
	}
};


void IRXSampleModule::initApp()
{
    OdEdCommandStackPtr pCommands = ::odedRegCmds();

	pCommands->addCommand(CommandImpl::createWrapper(OdEdCommandFn(NESTOUTPUT), OdString(IRXTEST_COMMANDS_GROUP_NAME), L"NESTOUTPUT"));
    return;

}


void IRXSampleModule::uninitApp()
{
    OdEdCommandStackPtr pCommands = ::odedRegCmds();
	pCommands->removeGroup(IRXTEST_COMMANDS_GROUP_NAME);
}


//string FindProjectFolder()
//{
//    char bufr[1024] = { 0 };
//    DWORD ret = GetModuleFileNameA(NULL, bufr, sizeof(bufr));
//    string dsa = string(bufr);
//    string::size_type pos = dsa.find_last_of("\\/");
//    string exePath = dsa.substr(0, pos);
//    return exePath + "\\bin\\Nesting";
//}


//void NESTOUTPUT(OdEdCommandContext* pCmdCtx)
//{
//    AFX_MANAGE_STATE(AfxGetStaticModuleState());
//
//    string sProjFold = FindProjectFolder();
//    wstring ws(sProjFold.begin(), sProjFold.end());
//    icutPrintf(L"\n%s", ws.c_str());
//
//    IcString str;
//    icedGetString(0, L"\nEnter Project Name:",str);
//    str = str + ws.c_str();
//
//    OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
//    OdDbDatabasePtr pDatabase = pDbCmdCtx->database();
//    OdDbBlockTableRecordPtr pBTR = pDatabase->getModelSpaceId().openObject(OdDb::kForWrite);
//}

std::wstring ReadRegistryValue(HKEY hKey, const std::wstring& valueName)
{
    DWORD dataSize = 0;
    if (RegQueryValueEx(hKey, valueName.c_str(), 0, NULL, NULL, &dataSize) != ERROR_SUCCESS)
    {
        return L"";
    }

    std::wstring result;
    result.resize(dataSize / sizeof(wchar_t));

    if (RegQueryValueEx(hKey, valueName.c_str(), 0, NULL, reinterpret_cast<LPBYTE>(&result[0]), &dataSize) != ERROR_SUCCESS)
    {
        return L"";
    }

    return result;
}

std::wstring FindProjectFolder()
{
    HKEY hk = 0;
    if (RegOpenKeyEx(HKEY_CURRENT_USER, L"Software\\MurariSoft", 0, KEY_READ, &hk) != ERROR_SUCCESS)
    {
        icutPrintf(L"Error: Could not open registry key.\n");
        return L"";
    }

    std::wstring projectName = ReadRegistryValue(hk, L"LastProject");
    RegCloseKey(hk);

    if (projectName.empty())
    {
        icutPrintf(L"Error: Could not read project name from registry.\n");
        return L"";
    }

    icutPrintf(L"Project Name from Registry: %s\n", projectName.c_str());

    wchar_t bufr[MAX_PATH] = { 0 };
    DWORD ret = GetModuleFileName(NULL, bufr, sizeof(bufr) / sizeof(bufr[0]));
    if (ret == 0)
    {
        icutPrintf(L"Error: Could not get module file name.\n");
        return L"";
    }
    std::wstring exePath = bufr;

    // icutPrintf(L"Exe Path: %s\n", exePath.c_str());
    std::wstring::size_type pos = exePath.rfind(L"\\");
    if (pos != std::wstring::npos)
    {
        exePath = exePath.substr(0, pos);
    }

    std::wstring projectFolderPath = exePath + L"\\bin\\Nesting\\" + projectName;
    // icutPrintf(L"Project Folder Path: %s\n", projectFolderPath.c_str());
    return projectFolderPath;
}

void CreateLayer(const std::string& layoutName, double layoutLength, double layoutWidth, OdDbDatabase* pDatabase)
{
    // Check if the layer exists.
    OdDbLayerTablePtr pLayers = pDatabase->getLayerTableId().safeOpenObject(OdDb::kForWrite);
    OdDbLayerTableRecordPtr pLayer;

    // Sanitize the layoutName to meet AutoCAD's constraints.
    std::string SLayout = layoutName;
    for (char& c : SLayout) {
        if (!isalnum(c) && c != '_') {
            // Replace invalid characters with underscores
            c = '_';
        }
    }

    if (pLayers->has(SLayout.c_str()))
    {
        pLayer = pLayers->getAt(SLayout.c_str()).safeOpenObject(OdDb::kForWrite);
        icutPrintf(L"\n%S Layer already exists, ignored", SLayout.c_str());
    }
    else
    {
        pLayer = OdDbLayerTableRecord::createObject();
        pLayer->setName(SLayout.c_str());
        pLayers->add(pLayer);
    }

    // Draw a rectangle on the layer.
    OdGePoint2d layoutStart(0.0, 0.0);
    OdGePoint2d layoutEnd(layoutLength, layoutWidth);

    OdDbBlockTableRecordPtr pBTR = pDatabase->getModelSpaceId().safeOpenObject(OdDb::kForWrite);
    OdDbPolylinePtr pLayoutRect = OdDbPolyline::createObject();
    // Add vertices to the polyline
    pLayoutRect->addVertexAt(0, OdGePoint2d(layoutStart.x, layoutStart.y));
    pLayoutRect->addVertexAt(1, OdGePoint2d(layoutEnd.x, layoutStart.y));
    pLayoutRect->addVertexAt(2, OdGePoint2d(layoutEnd.x, layoutEnd.y));
    pLayoutRect->addVertexAt(3, OdGePoint2d(layoutStart.x, layoutEnd.y));
    pLayoutRect->addVertexAt(4, OdGePoint2d(layoutStart.x, layoutStart.y));

    pLayoutRect->setLayer(pLayer->objectId());

    pBTR->appendOdDbEntity(pLayoutRect);

    icutPrintf(L"\n%S Layer created with a rectangle", SLayout.c_str());
}
struct InstanceDetails
{
    double xMatrix;
    double yMatrix;
    double angle;
};

void CreateProfiles(const std::wstring& partFilePath, OdDbBlockTableRecordPtr pBTR, const double xMatrix, const double yMatrix, const double angle)
{
    std::wifstream profileFile(partFilePath);
    if (!profileFile.is_open())
    {
        icutPrintf(L"Failed to open part file: %s", partFilePath.c_str());
        return;
    }
    OdGeMatrix3d TransMat;
    TransMat.setToTranslation(OdGeVector3d(xMatrix, yMatrix, 0.0));
    double rotAng = angle * OdaPI / 180.0;
    OdGeMatrix3d RotMat;
    RotMat.setToRotation(rotAng, OdGeVector3d::kZAxis);

    std::wstring partLine;
    OdGePoint3d pStpt(0, 0, 0);
    OdGePoint3d pEnpt(0, 0, 0);
    bool lastCommandWasArc = false;
    std::vector<OdDbEntityPtr> entities;

    while (std::getline(profileFile, partLine))
    {
        std::wistringstream iss(partLine);
        std::wstring key;

        while (iss >> key)
        {
            if (key == L"STARTPT")
            {
                double startX, startY;
                iss >> startX >> startY;
                pStpt = OdGePoint3d(startX, startY, 0);
                lastCommandWasArc = false;
            }
            else if (key == L"VLINE")
            {
                double endX, endY;
                iss >> endX >> endY;
                pEnpt = OdGePoint3d(endX, endY, 0);

                OdDbLinePtr pLine = OdDbLine::createObject();
                pLine->setStartPoint(pStpt);
                pLine->setEndPoint(pEnpt);

                pLine->transformBy(RotMat);
                pLine->transformBy(TransMat);

                pBTR->appendOdDbEntity(pLine);

                lastCommandWasArc = false;

                icutPrintf(L"\nLine created from (%f, %f, %f) to (%f, %f, %f)",
                    pStpt.x, pStpt.y, pStpt.z, pEnpt.x, pEnpt.y, pEnpt.z);

                pStpt = pEnpt;
            }
            else if (key == L"VARC")
            {
                double centerX, centerY, includedAngle;
                iss >> centerX >> centerY >> includedAngle;

                OdGePoint3d pCen(centerX, centerY, 0);
                OdGeVector3d vRad = pStpt - pCen;
                double dRad = vRad.length();
                double dStAng = OdGeVector3d::kXAxis.angleTo(vRad, OdGeVector3d::kZAxis);
                double dEnAng = dStAng + includedAngle;

                OdDbArcPtr pArc = OdDbArc::createObject();
                pArc->setCenter(pCen);
                pArc->setRadius(dRad);
                pArc->setStartAngle(dStAng);
                pArc->setEndAngle(dEnAng);

                pBTR->appendOdDbEntity(pArc);
                entities.push_back(pArc);

                pArc->transformBy(RotMat);
                pArc->transformBy(TransMat);

                double arcX = pCen.x + dRad * cos(dEnAng);
                double arcY = pCen.y + dRad * sin(dEnAng);
                pEnpt = OdGePoint3d(arcX, arcY, 0);

                icutPrintf(L"\nArc created with center (%f, %f, %f), radius: %f, start angle: %f, end angle: %f",
                    pCen.x, pCen.y, pCen.z, dRad, dStAng, dEnAng);
                pStpt = pEnpt;
                lastCommandWasArc = true;
            }
            else if (key == L"VCIRCLE")
            {
                double centerX, centerY, radius;
                iss >> centerX >> centerY >> radius;

                OdGePoint3d pCen(centerX, centerY, 0);

                OdDbCirclePtr pCircle = OdDbCircle::createObject();
                pCircle->setCenter(pCen);
                pCircle->setRadius(radius);

                pBTR->appendOdDbEntity(pCircle);
                entities.push_back(pCircle);

                pCircle->transformBy(RotMat);
                pCircle->transformBy(TransMat);

                icutPrintf(L"\nCircle created with center (%f, %f, %f) and radius: %f",
                    pCen.x, pCen.y, pCen.z, radius);
            }
        }
    }
}


void ProcessNopFile(const std::string& nopFilePath, OdDbDatabase* pDatabase)
{
    std::ifstream nopFile(nopFilePath);
    if (!nopFile.is_open())
    {
        icutPrintf(L"Failed to open .nop file: %S", nopFilePath.c_str());
        return;
    }
    std::string line;
    std::string layoutName;
    double layoutLength = 0.0;
    double layoutWidth = 0.0;
    bool insideLayout = false;
    bool insidePart = false;
    std::string currentPartName;
    int currentPartInstances = 0;
    int currentLayoutNumber = 0;
    int instanceCount = 0;
    std::vector<std::tuple<double, double, double>> partInstances;
    std::wstring baseFolderPath = L"D:/NESTING/NL2023R1/Deliverables/Testapp/VC141/x86/";

    bool firstPartFileNotFound = false;

    while (std::getline(nopFile, line))
    {
        std::istringstream iss(line);
        std::string token;
        iss >> token;

        if (token == "(SUMMARY")
        {
            break;
        }

        if (token == "(LAYOUT")
        {
            insideLayout = true;
            iss >> currentLayoutNumber;
            layoutName = "Layer " + std::to_string(currentLayoutNumber);
        }
        else if (token == "(NAME" && insidePart)
        {
            std::string partName;
            iss >> partName;
            partName.pop_back();
            currentPartName = partName;
            icutPrintf(L"\nLayout Name: %S", layoutName.c_str());
            icutPrintf(L"\nPart Name: %S", currentPartName.c_str());

        }
        else if (token == "(PART")
        {
            insidePart = true;
            instanceCount = 1;
        }
        else if (token == "(INSTANCES" && insidePart)
        {
            iss >> currentPartInstances;
        }
        else if (token == "(LENGTH" && insideLayout)
        {
            iss >> layoutLength;
        }
        else if (token == "(WIDTH" && insideLayout)
        {
            iss >> layoutWidth;
        }
        else if (token == "(NUMBER")
        {
            int currentLayoutNumber;
            iss >> currentLayoutNumber;
            if (currentLayoutNumber > 0)
            {
                layoutName = "Layer " + std::to_string(currentLayoutNumber);
            }
        }
        else if (token == "(INSTANCE" && insidePart)
        {
            double xMatrix, yMatrix, angle;
            while (std::getline(nopFile, line))
            {
                std::istringstream instStream(line);
                std::string instToken;
                instStream >> instToken;
                if (instToken == "(XMATRIX")
                {
                    instStream >> xMatrix;
                }
                else if (instToken == "(YMATRIX")
                {
                    instStream >> yMatrix;
                }
                else if (instToken == "(ANGLE")
                {
                    instStream >> angle;
                }
                else if (instToken == ")")
                {
                    icutPrintf(L"\nInstance %d - XMATRIX: %f, YMATRIX: %f, ANGLE: %f", instanceCount, xMatrix, yMatrix, angle);

                    std::wstring partFileName = std::wstring(currentPartName.begin(), currentPartName.end());
                    std::wstring partFilePath = baseFolderPath + partFileName;
                    if (std::filesystem::exists(partFilePath))
                    {
                        CreateProfiles(partFilePath, pDatabase->getModelSpaceId().openObject(OdDb::kForWrite), xMatrix, yMatrix, angle);
                    }
                    partInstances.push_back(std::make_tuple(xMatrix, yMatrix, angle));
                    ++instanceCount;
                    break;
                }
            }
        }
        else if (token == ")")
        {
            if (insideLayout)
            {
                insideLayout = false;
                if (!layoutName.empty() && layoutLength > 0.0 && layoutWidth > 0.0)
                {
                    CreateLayer(layoutName, layoutLength, layoutWidth, pDatabase);
                }
            }
            insidePart = false;
            layoutName.clear();
            layoutLength = 0.0;
            layoutWidth = 0.0;
        }
    }
}

void NESTOUTPUT(OdEdCommandContext* pCmdCtx)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());

    OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
    OdDbDatabasePtr pDatabase = pDbCmdCtx->database();
    OdDbBlockTableRecordPtr pBTR = pDatabase->getModelSpaceId().openObject(OdDb::kForWrite);
    std::string nopFilePath = "C:/Program Files/ActCAD/ActCAD 2023 Map Drafter/bin/Nesting/1234/1234.nop";
    ProcessNopFile(nopFilePath, pDatabase);
}