#include "StdAfx.h"
#include "OdaCommon.h"
#include "afxtoolbar.h"
#include "RxObjectImpl.h"
#include "DbBlockTableRecord.h"
#include "DbText.h"
#include "DbDictionary.h"
#include "DbCircle.h"
#include "DbGroup.h"
#include "DbSymUtl.h"
#include "DbBlockTable.h"
#include "DbViewportTable.h"
#include "DbViewport.h"
#include "DbLayerTable.h"
#include "DbAbstractViewTableRecord.h"
#include "DbVisualStyle.h"
#include "DbLayerTableRecord.h"
#include "DbSymUtl.h"
#include "../../inc/ArxCompat.h"
#include "DbRegAppTable.h"
#include "DbRegAppTableRecord.h"
#include "DbCommandContext.h"
#include "DbLinetypeTableRecord.h"
#include "Db3dPolyline.h"
#include "DbAlignedDimension.h"
#include "DbRotatedDimension.h"
#include "Db3dPolylineVertex.h"
#include "DbRadialDimensionLarge.h"
#include "DbRadialDimension.h"
#include "Db3PointAngularDimension.h"
#include"DbLeader.h"
#include "StringArray.h"
#include "DbEvalGraph.h"
#include"Dbtext.h"

#include "IRXSampleModule.h"
#include "IrxSampleDialog.h"
#include "IRXPreviewDialog.h"
#include "IcApi.h"
#include "windows.h"

#include "IcApDocManager.h"
#include "IcApDocumentIterator.h"
#include "IcApDocument.h"
#include "IcEdInputPointManager.h"
#include "IcadDbHostApplicationServices.h"
#include "IcGs.h"
#include "icedsds.h"
#include "IcColorSettings.h"

#include "sds.h"

#include "StaticRxObject.h"
#include "DbPolyline.h"
#include "DbSpLine.h"
#include "DbArc.h"
#include "Gi/GiDrawableImpl.h"
#include "Gi/GiWorldDraw.h"
#include "Gi/GiViewportDraw.h"

#include "Ge/GeExtents2d.h"
#include "DbUserIO.h"

#include "MultipleEntitiesJig.h"
#include "Db3dPolyline.h"
#include "cmath"
#include "windows.h"

#include "ios"
#include "iostream"
#include "fstream"
#include "sstream"

#include "OdaCommon.h"
#include "RxObject.h"
#include "DbBaseDatabase.h"
#include "DbDictionary.h"
#include "DbObjectIterator.h"
#include "DbText.h"
#include"Dbfcf.h"
#include"cmath"
#include"iomanip"
#include"DbPoint.h"
#include"OdString.h"
#include <string.h>
#include <filesystem>
#include "DbIdMapping.h"
#include "DbFiler.h" //for dxfout options

using namespace std;

ODRX_DEFINE_DYNAMIC_MODULE(IRXSampleModule);
typedef void (*OdEdCommandFn)(OdEdCommandContext* pCmdCtx);

extern void NESTOUTPUT(OdEdCommandContext* pCmdCtx);

class CommandImpl : public OdEdCommand
{
    OdEdCommandFn m_execute;
    OdString m_szCmdGroup;
    OdString m_szGlobalName;
    OdString m_szLocalName;
public:
    void execute(OdEdCommandContext* pCmdCtx) { m_execute(pCmdCtx); }
    const OdString globalName() const { return m_szGlobalName; }
    const OdString localName() const { return m_szGlobalName; }
    const OdString groupName() const { return m_szCmdGroup; }

    static OdEdCommandPtr createWrapper(OdEdCommandFn executeFn,
        const OdChar* szCmdGroup,
        const OdChar* szGlobalName)
    {
        OdSmartPtr<OdEdCommand> pRes = OdEdCommand::createObject(szCmdGroup, szGlobalName, szGlobalName, kUsePickset, executeFn, 0);
        return pRes;
    }
};

void IRXSampleModule::initApp()
{
    OdEdCommandStackPtr pCommands = ::odedRegCmds();

    pCommands->addCommand(CommandImpl::createWrapper(OdEdCommandFn(NESTOUTPUT), OdString(IRXTEST_COMMANDS_GROUP_NAME), L"NESTOUTPUT"));
    return;

}

void IRXSampleModule::uninitApp()
{
    OdEdCommandStackPtr pCommands = ::odedRegCmds();
    pCommands->removeGroup(IRXTEST_COMMANDS_GROUP_NAME);
}

string FindProjectFolder()
{
    char bufr[1024] = { 0 };
    DWORD ret = GetModuleFileNameA(NULL, bufr, sizeof(bufr));
    string dsa = string(bufr);
    string::size_type pos = dsa.find_last_of("\\/");
    string exePath = dsa.substr(0, pos);
    return exePath + "\\bin\\Nesting";
}

OdDbObjectId CreateLayer(const std::string& layoutName, OdDbDatabase* pDatabase)
{
    OdDbObjectId idLayer = OdDbObjectId::kNull;
    OdDbLayerTablePtr pLayers = pDatabase->getLayerTableId().safeOpenObject(OdDb::kForWrite);
    std::string sLnm = layoutName;
    for (char& c : sLnm) {
        if (!isalnum(c) && c != '_')
        {
            c = '_';
        }
    }
    if (pLayers->has(sLnm.c_str()))
    {
        idLayer = pLayers->getAt(sLnm.c_str()); 
      // icutPrintf(L"\n%S Layer already exists, ignored", sLnm.c_str());
    }
    else
    {
        OdDbLayerTableRecordPtr pLayer = OdDbLayerTableRecord::createObject();
        pLayer->setName(sLnm.c_str());
        idLayer = pLayers->add(pLayer);
    }    
    return idLayer;
}

struct InstanceDetails
{
    double xMatrix;
    double yMatrix;
    double angle;
};

void ImportDwgAsBlock(OdString fNm, OdDbDatabasePtr pDb, double xMatrix, double yMatrix, double angle, OdDbObjectId layerId)
{
    //----finding file name------
    wstring str(fNm.c_str());
    size_t pos = str.find_last_of(L"\\/");
    str = str.substr(pos + 1, str.length());
    pos = str.find_last_of(L".");
    str = str.substr(0, pos);
    //icutPrintf(L"\n%s", str.c_str());
    //----------------------------

    OdDbDatabasePtr pSrcDb = pDb->appServices()->readFile(fNm);
    OdDbObjectId obj = pDb->insert(L"*Model_Space", (OdString)str.c_str(), pSrcDb, true);
    OdDbBlockTableRecordPtr pBTR = pDb->getModelSpaceId().safeOpenObject(OdDb::kForWrite);
    OdDbBlockReferencePtr pBlkRef = OdDbBlockReference::createObject();
    OdGeMatrix3d transMat, rotMat;
    transMat.setToTranslation(OdGeVector3d(xMatrix, yMatrix, 0.0));
    double rotAng = angle * OdaPI / 180.0;
    rotMat.setToRotation(rotAng, OdGeVector3d::kZAxis);
    pBlkRef->transformBy(rotMat);
    pBlkRef->transformBy(transMat);
    pBlkRef->setBlockTableRecord(obj);   
    pBTR->appendOdDbEntity(pBlkRef);
    pBlkRef->setLayer(layerId);
}


void ProcessNopFile(const std::string& nopFilePath, OdDbDatabasePtr pDb)
{
    std::ifstream nopFile(nopFilePath);
    if (!nopFile.is_open())
    {
        icutPrintf(L"\nFailed to open .nop file as: %S", nopFilePath.c_str());
        return;
    }
    size_t dotPos = nopFilePath.find_last_of(".");
    std::string baseFolderPath = nopFilePath.substr(0, dotPos);
    size_t lastSlashPos = baseFolderPath.find_last_of("/\\");
    if (lastSlashPos != std::string::npos)
    {
        baseFolderPath = baseFolderPath.substr(0, lastSlashPos);
    }

    std::string line;
    std::string layoutName;
    double layoutLength = 0.0;
    double layoutWidth = 0.0;
    int layoutNumber = 0;
    bool insideLayout = false;
    bool insidePart = false;
    std::string currentPartName;
    int currentPartInstances = 0;
    OdDbObjectId idLayer = OdDbObjectId::kNull;

    while (std::getline(nopFile, line))
    {
        std::istringstream iss(line);
        std::string token;
        iss >> token;

        if (token == "(PARTLIST")
        {
            break;
        }
        if (token == "(LAYOUT")
        {
            insideLayout = true;
        }
        else if (token == "(NUMBER" && insideLayout)
        {
            iss >> layoutNumber;
            layoutName = "Layer_" + std::to_string(layoutNumber);
            if (idLayer.isNull())
            {
                idLayer = CreateLayer(layoutName, pDb);
            }
        }
        else if (token == "(PART")
        {
            insidePart = true;
        }
        else if (token == "(SHEET" && insideLayout)
        {
            std::string sheetPath;
            int sheetInstances = 0;
            while (std::getline(nopFile, line))
            {
                std::istringstream sheetLine(line);
                std::string sheetToken;
                sheetLine >> sheetToken;
                if (sheetToken == "(NAME")
                {
                    std::getline(sheetLine, sheetPath, '(');
                    std::getline(sheetLine, sheetPath, ')');
                    sheetPath = sheetPath.substr(1);
                    sheetPath.erase(sheetPath.begin(), std::find_if(sheetPath.begin(), sheetPath.end(), [](int ch)
                        {
                            return !std::isspace(ch);
                        }));
                    if (!sheetPath.empty() && sheetPath.back() == ')')
                    {
                        sheetPath.pop_back();
                    }
                    size_t extensionPos = sheetPath.find_last_of('.');
                    if (extensionPos != std::string::npos)
                    {
                        sheetPath = sheetPath.substr(0, extensionPos) + ".dwg";
                    }
                   // icutPrintf(L"\nSheet Path: %S", sheetPath.c_str());
                    OdString dwgFilePath = sheetPath.c_str();
                    if (std::filesystem::exists(dwgFilePath.c_str()))
                    {
                        ImportDwgAsBlock(dwgFilePath, pDb, 0.0, 0.0, 0.0, idLayer);
                    }
                    break;
                }
            }
        }
        else if (token == ")")
        {
            insideLayout = false;
            insidePart = false;
        }
        else if (token == "(NAME" && insidePart)
        {
            std::string partName;
            iss >> std::ws;
            std::getline(iss, partName, ')');
            size_t extensionPos = partName.find_last_of('.');
            if (extensionPos != std::string::npos)
            {
                partName = partName.substr(0, extensionPos) + ".dwg";
            }
            currentPartName = partName;
            //icutPrintf(L"\npart Path: %S", currentPartName.c_str());
        }
        else if (token == "(INSTANCES" && insidePart)
        {
            iss >> currentPartInstances;
            for (int i = 0; i < currentPartInstances; ++i)
            {
                double xMatrix, yMatrix, angle;
                while (std::getline(nopFile, line))
                {
                    std::istringstream instLine(line);
                    std::string instToken;
                    instLine >> instToken;
                    if (instToken == "(XMATRIX")
                    {
                        instLine >> xMatrix;
                    }
                    else if (instToken == "(YMATRIX")
                    {
                        instLine >> yMatrix;
                    }
                    else if (instToken == "(ANGLE")
                    {
                        instLine >> angle;
                    }
                    else if (instToken == ")")
                    {
                        OdString partFilePath = currentPartName.c_str();
                        if (std::filesystem::exists(partFilePath.c_str()))
                        {
                            ImportDwgAsBlock(partFilePath, pDb, xMatrix, yMatrix, angle, idLayer);
                        }
                        break;
                    }
                }
            }
        }
    }
}


void NESTOUTPUT(OdEdCommandContext* pCmdCtx)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
    OdDbDatabasePtr pDb = pDbCmdCtx->database();

    HKEY hk = 0;
    wstring projectName;
    if (RegOpenKeyEx(HKEY_CURRENT_USER, L"Software\\MurariSoft", 0, KEY_READ, &hk) == ERROR_SUCCESS)
    {
        const int maxBufSize = 256;
        wchar_t valueBuf[maxBufSize];
        DWORD bufSize = maxBufSize * sizeof(wchar_t);
        if (RegQueryValueEx(hk, L"LastProject", NULL, NULL, (LPBYTE)valueBuf, &bufSize) == ERROR_SUCCESS)
        {
            projectName = valueBuf;
        }
        RegCloseKey(hk);
    }

    string sProjFold = FindProjectFolder();
    wstring ws(sProjFold.begin(), sProjFold.end());
    ws += L"\\" + projectName +L"\\" + projectName+L".nop";

    //icutPrintf(L"\n%s", ws.c_str());
    string sProjFoldStr(ws.begin(), ws.end());
    ProcessNopFile(sProjFoldStr, pDb);
}
