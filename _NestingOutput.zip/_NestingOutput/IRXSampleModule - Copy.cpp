#include "StdAfx.h"
#include "OdaCommon.h"
#include "afxtoolbar.h"
#include "RxObjectImpl.h"
#include "DbBlockTableRecord.h"
#include "DbText.h"
#include "DbDictionary.h"
#include "DbCircle.h"
#include "DbGroup.h"
#include "DbSymUtl.h"
#include "DbBlockTable.h"
#include "DbViewportTable.h"
#include "DbViewport.h"
#include "DbLayerTable.h"
#include "DbAbstractViewTableRecord.h"
#include "DbVisualStyle.h"
#include "DbLayerTableRecord.h"
#include "DbSymUtl.h"
#include "../../inc/ArxCompat.h"
#include "DbRegAppTable.h"
#include "DbRegAppTableRecord.h"
#include "DbCommandContext.h"
#include "DbLinetypeTableRecord.h"
#include "Db3dPolyline.h"
#include "DbAlignedDimension.h"
#include "DbRotatedDimension.h"
#include "Db3dPolylineVertex.h"
#include "DbRadialDimensionLarge.h"
#include "DbRadialDimension.h"
#include "Db3PointAngularDimension.h"
#include"DbLeader.h"
#include "StringArray.h"
#include "DbEvalGraph.h"
#include"Dbtext.h"

#include "IRXSampleModule.h"
#include "IrxSampleDialog.h"
#include "IRXPreviewDialog.h"
#include "IcApi.h"
#include "windows.h"

#include "IcApDocManager.h"
#include "IcApDocumentIterator.h"
#include "IcApDocument.h"
#include "IcEdInputPointManager.h"
#include "IcadDbHostApplicationServices.h"
#include "IcGs.h"
#include "icedsds.h"



#include "IcColorSettings.h"

#include "sds.h"

#include "StaticRxObject.h"
#include "DbPolyline.h"
#include "DbSpLine.h"
#include "DbArc.h"


#include "Gi/GiDrawableImpl.h"
#include "Gi/GiWorldDraw.h"
#include "Gi/GiViewportDraw.h"

#include "Ge/GeExtents2d.h"
#include "DbUserIO.h"

#include "MultipleEntitiesJig.h"
#include "Db3dPolyline.h"
#include "cmath"
#include "windows.h"

#include "ios"
#include "iostream"
#include "fstream"
#include "sstream"

#include "OdaCommon.h"
#include "RxObject.h"
#include "DbBaseDatabase.h"
#include "DbDictionary.h"
#include "DbObjectIterator.h"
#include "DbText.h"
#include"Dbfcf.h"
#include"cmath"
#include"iomanip"
#include"DbPoint.h"
#include"OdString.h"
#include <string.h>
#include <filesystem>

using namespace std;

ODRX_DEFINE_DYNAMIC_MODULE(IRXSampleModule);
typedef void (*OdEdCommandFn)(OdEdCommandContext* pCmdCtx);

extern void NESTINPUT(OdEdCommandContext* pCmdCtx);

class CommandImpl : public OdEdCommand
{
	OdEdCommandFn m_execute;
	OdString m_szCmdGroup;
	OdString m_szGlobalName;
    OdString m_szLocalName;
public:
	void execute(OdEdCommandContext* pCmdCtx) { m_execute(pCmdCtx); }
	const OdString globalName() const { return m_szGlobalName; }
	const OdString localName() const { return m_szGlobalName; }
	const OdString groupName() const { return m_szCmdGroup; }

	static OdEdCommandPtr createWrapper(OdEdCommandFn executeFn,
		const OdChar* szCmdGroup,
		const OdChar* szGlobalName)
	{
		OdSmartPtr<OdEdCommand> pRes = OdEdCommand::createObject(szCmdGroup, szGlobalName, szGlobalName, kUsePickset, executeFn, 0);
		return pRes;
	}
};


void IRXSampleModule::initApp()
{
    OdEdCommandStackPtr pCommands = ::odedRegCmds();

	pCommands->addCommand(CommandImpl::createWrapper(OdEdCommandFn(NESTINPUT), OdString(IRXTEST_COMMANDS_GROUP_NAME), L"NESTINPUT"));
    return;

}


void IRXSampleModule::uninitApp()
{
    OdEdCommandStackPtr pCommands = ::odedRegCmds();
	pCommands->removeGroup(IRXTEST_COMMANDS_GROUP_NAME);

}

string FindProjectFolder()
{
    char bufr[1024] = { 0 };
    DWORD ret = GetModuleFileNameA(NULL, bufr, sizeof(bufr));
    string dsa = string(bufr);
    string::size_type pos = dsa.find_last_of("\\/");
    string exePath = dsa.substr(0, pos);
    return exePath + "/" + "Nesting";
}



bool GetProjectFolder(const std::wstring& directory, std::wstring& binFolder) 
{
    WIN32_FIND_DATAW findFileData;
    HANDLE hFind = FindFirstFileW((directory + L"\\*").c_str(), &findFileData);

    if (hFind == INVALID_HANDLE_VALUE) {
        return false;
    }

    do {
        if (findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            if (wcscmp(findFileData.cFileName, L"bin") == 0) {
                binFolder = directory + L"\\" + findFileData.cFileName;
                FindClose(hFind);
                return true; // Found the bin folder
            }
            else if (wcscmp(findFileData.cFileName, L".") != 0 && wcscmp(findFileData.cFileName, L"..") != 0) {
                std::wstring subdirectory = directory + L"\\" + findFileData.cFileName;
                if (GetProjectFolder(subdirectory, binFolder)) {
                    FindClose(hFind);
                    return true;
                }
            }
        }
    } while (FindNextFileW(hFind, &findFileData) != 0);

    FindClose(hFind);
    return false;
}

// Function to search for .nop and .prf files recursively
void SearchForFiles(const std::wstring& directory, std::vector<std::wstring>& nopFiles, std::vector<std::wstring>& prfFiles) {
    WIN32_FIND_DATAW findFileData;
    HANDLE hFind = FindFirstFileW((directory + L"\\*").c_str(), &findFileData);

    if (hFind == INVALID_HANDLE_VALUE) {
        return;
    }

    do {
        if (findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            if (wcscmp(findFileData.cFileName, L".") != 0 && wcscmp(findFileData.cFileName, L"..") != 0) {
                std::wstring subdirectory = directory + L"\\" + findFileData.cFileName;
                SearchForFiles(subdirectory, nopFiles, prfFiles);
            }
        }
        else {
            std::wstring fileName = findFileData.cFileName;
            if (fileName.length() >= 4) {
                std::wstring extension = fileName.substr(fileName.length() - 4);
                if (extension == L".nop") {
                    nopFiles.push_back(directory + L"\\" + fileName);
                }
                else if (extension == L".prf") {
                    prfFiles.push_back(directory + L"\\" + fileName);
                }
            }
        }
    } while (FindNextFileW(hFind, &findFileData) != 0);

    FindClose(hFind);
}



void ProcessPartFile(const std::wstring& prfFile, const OdGeMatrix3d& transMat, const OdGeMatrix3d& rotMat, OdDbBlockTableRecordPtr pBTR)
{
    std::wifstream partFile(prfFile);
    if (!partFile.is_open())
    {
        std::wcout << L"Error: Unable to open .prf file: " << prfFile << std::endl;
        return;
    }

    std::wstring partLine;

    OdGePoint3d pStpt(0, 0, 0);
    OdGePoint3d pEnpt(0, 0, 0);
    bool lastCommandWasArc = false;

    while (std::getline(partFile, partLine))
    {
        std::wistringstream iss(partLine);
        std::wstring key;

        while (iss >> key)
        {
            if (key == L"STARTPT")
            {
                double startX, startY;
                iss >> startX >> startY;
                pStpt = OdGePoint3d(startX, startY, 0);
                lastCommandWasArc = false;
            }
            else if (key == L"VLINE")
            {
                double endX, endY;
                iss >> endX >> endY;
                pEnpt = OdGePoint3d(endX, endY, 0);

                OdDbLinePtr pLine = OdDbLine::createObject();
                pLine->setStartPoint(pStpt);
                pLine->setEndPoint(pEnpt);

                pBTR->appendOdDbEntity(pLine);
                pLine->transformBy(rotMat);
                pLine->transformBy(transMat);

                lastCommandWasArc = false;

                pStpt = pEnpt;
            }
            else if (key == L"VARC")
            {
                double centerX, centerY, includedAngle;
                iss >> centerX >> centerY >> includedAngle;

                OdGePoint3d pCen(centerX, centerY, 0);
                OdGeVector3d vRad = pStpt - pCen;
                double dRad = vRad.length();
                double dStAng = OdGeVector3d::kXAxis.angleTo(vRad, OdGeVector3d::kZAxis);
                double dEnAng = dStAng + includedAngle;

                OdDbArcPtr pArc = OdDbArc::createObject();
                pArc->setCenter(pCen);
                pArc->setRadius(dRad);
                pArc->setStartAngle(dStAng);
                pArc->setEndAngle(dEnAng);

                pBTR->appendOdDbEntity(pArc);
                pArc->transformBy(rotMat);
                pArc->transformBy(transMat);

                double arcX = pCen.x + dRad * cos(dEnAng);
                double arcY = pCen.y + dRad * sin(dEnAng);
                pEnpt = OdGePoint3d(arcX, arcY, 0);

                pStpt = pEnpt;
                lastCommandWasArc = true;
            }
        }
    }
}


void NESTINPUT(OdEdCommandContext* pCmdCtx)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());

    OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
    OdDbDatabasePtr pDatabase = pDbCmdCtx->database();
    OdDbBlockTableRecordPtr pBTR = pDatabase->getModelSpaceId().openObject(OdDb::kForWrite);

    wchar_t actcadInstallDir[MAX_PATH];
    if (SHGetFolderPathW(NULL, CSIDL_PROGRAM_FILES, NULL, 0, actcadInstallDir) != S_OK)
    {
        std::wcout << L"Error: Failed to get the installation directory." << std::endl;
        return;
    }

    std::wstring binFolder;
    if (!GetProjectFolder(actcadInstallDir, binFolder))
    {
        std::wcout << L"Error: Bin folder not found." << std::endl;
        return;
    }

    std::wstring nestingFolder = binFolder + L"\\Nesting";


    std::vector<std::wstring> nopFiles;
    std::vector<std::wstring> prfFiles;

    SearchForFiles(nestingFolder, nopFiles, prfFiles);
    for (const std::wstring& nopFile : nopFiles) 
    {
        std::wifstream layoutFile(nopFile);
        if (!layoutFile.is_open()) 
        {
            std::wcout << L"Error: Unable to open .nop file: " << nopFile << std::endl;
            continue;
        }

        int numlay = 1;
        bool processLayout = false;
        bool processPart = false;
        std::wstring line;
        int instcnt = 0;
        bool inst = false;
        std::wstring partName;
        int numinst = 0;
        double layoutLength = 0.0;
        double layoutWidth = 0.0;

        std::wifstream currentPartProfile;

        while (std::getline(layoutFile, line))
        {
            std::wistringstream iss(line);
            std::wstring key;

            if (iss >> key)
            {
                if (key == L"(LAYOUT")
                {
                    processLayout = true;
                    processPart = false;
                    icutPrintf(L"\nLayout %d details:", numlay);

                    // Creating a new layer for this layout
                    std::wstring layName = L"Layout " + std::to_wstring(numlay);
                    OdDbObjectId idLayer;
                    OdDbLayerTablePtr pLayers = pDatabase->getLayerTableId().safeOpenObject(OdDb::kForWrite);
                    OdDbLayerTableRecordPtr pLayer = OdDbLayerTableRecord::createObject();
                    pLayer->setName(layName.c_str());
                    idLayer = pLayers->add(pLayer);

                    numlay++;
                }
                else if (key == L"(LENGTH")
                {
                    iss >> layoutLength;
                }
                else if (key == L"(WIDTH")
                {
                    iss >> layoutWidth;
                }
                else if (key == L"(SUMMARY") 
                {
                    break;
                }
                else if (processLayout) 
                {
                    if (key == L"(PART")
                    {
                        iss >> partName;
                        if (partName.back() == L')') 
                        {
                            partName.pop_back();
                        }
                        processPart = true;
                        instcnt = 0;
                        inst = false;

                        if (currentPartProfile.is_open())
                        {
                            currentPartProfile.close();
                        }                    
                        bool partFileFound = false;
                        std::wstring prfFileName = partName + L".prf";
                        for (const std::wstring& prfFile : prfFiles)
                        {
                            if (prfFile == prfFileName)
                            {
                                currentPartProfile.open(prfFile);
                                if (currentPartProfile.is_open())
                                {
                                    partFileFound = true;
                                    break;
                                }
                            }
                        }

                        if (!partFileFound)
                        {
                            icutPrintf(L"\nPart file not found for %s. Skipping this part.", partName.c_str());
                            continue; 
                        }

                        currentPartProfile.clear();

                        OdGePoint2d layoutStart(0.0, 0.0);
                        OdGePoint2d layoutEnd(layoutLength, layoutWidth);

                        OdDbPolylinePtr pLayoutRect = OdDbPolyline::createObject();
                       
                        pLayoutRect->addVertexAt(0, OdGePoint2d(layoutStart.x, layoutStart.y));
                        pLayoutRect->addVertexAt(1, OdGePoint2d(layoutEnd.x, layoutStart.y));
                        pLayoutRect->addVertexAt(2, OdGePoint2d(layoutEnd.x, layoutEnd.y));
                        pLayoutRect->addVertexAt(3, OdGePoint2d(layoutStart.x, layoutEnd.y));
                        pLayoutRect->addVertexAt(4, OdGePoint2d(layoutStart.x, layoutStart.y));
                        pBTR->appendOdDbEntity(pLayoutRect);
                    }
                    else if (key == L"(NAME")
                    {
                        iss >> partName;
                        icutPrintf(L"\nPart Name: %s", partName.c_str());
                    }
                    else if (processPart)
                    {
                        if (key == L"(INSTANCES") 
                        {
                            iss >> numinst;
                            icutPrintf(L"\nNum Instances: %d", numinst);
                        }
                        else if (key == L"(INSTANCE")
                        {
                            instcnt++;
                            inst = true;

                            double xMatrix, yMatrix, angle;
                            bool readXMatrix = false, readYMatrix = false, readAngle = false;

                            while (std::getline(layoutFile, line) && line != L")")
                            {
                                std::wistringstream iss(line);
                                std::wstring instanceKey;

                                if (iss >> instanceKey) {
                                    if (instanceKey == L"(XMATRIX")
                                    {
                                        iss >> xMatrix;
                                        readXMatrix = true;
                                    }
                                    else if (instanceKey == L"(YMATRIX")
                                    {
                                        iss >> yMatrix;
                                        readYMatrix = true;
                                    }
                                    else if (instanceKey == L"(ANGLE")
                                    {
                                        iss >> angle;
                                        readAngle = true;
                                    }

                                    if (readXMatrix && readYMatrix && readAngle)
                                    {
                                        break;
                                    }
                                }
                            } 
                            std::wifstream partFile;

                            for (const std::wstring& prfFile : prfFiles)
                            {
                                partFile.open(prfFile);
                                if (!partFile.is_open())
                                {
                                    std::wcout << L"Error: Unable to open .prf file: " << prfFile << std::endl;
                                    continue;
                                }
                                if (readXMatrix && readYMatrix && readAngle)
                                {
                                    icutPrintf(L"\nInstance %d: XMATRIX: %.6f, YMATRIX: %.6f, ANGLE: %.6f", instcnt, xMatrix, yMatrix, angle);

                                    OdGeMatrix3d TransMat;
                                    TransMat.setToTranslation(OdGeVector3d(xMatrix, yMatrix, 0.0));

                                    double RotAng = angle * OdaPI / 180.0;
                                    OdGeMatrix3d RotMat;
                                    RotMat.setToRotation(RotAng, OdGeVector3d::kZAxis);

                                    std::vector<OdDbEntityPtr> entities;
                                    std::wstring partLine;
                                    OdGePoint3d pStpt(0, 0, 0);
                                    OdGePoint3d pEnpt(0, 0, 0);
                                    bool lastCommandWasArc = false;

                                    while (std::getline(partFile, partLine))
                                    {
                                        std::wistringstream iss(partLine);
                                        std::wstring key;

                                        while (iss >> key) 
                                        {
                                            if (key == L"STARTPT") 
                                            {
                                                double startX, startY;
                                                iss >> startX >> startY;
                                                pStpt = OdGePoint3d(startX, startY, 0);
                                                lastCommandWasArc = false;
                                            }
                                            else if (key == L"VLINE") 
                                            {
                                                double endX, endY;
                                                iss >> endX >> endY;
                                                pEnpt = OdGePoint3d(endX, endY, 0);

                                                OdDbLinePtr pLine = OdDbLine::createObject();
                                                pLine->setStartPoint(pStpt);
                                                pLine->setEndPoint(pEnpt);

                                                pBTR->appendOdDbEntity(pLine);
                                                entities.push_back(pLine);

                                                pLine->transformBy(RotMat);
                                                pLine->transformBy(TransMat);

                                                lastCommandWasArc = false;

                                                icutPrintf(L"\nLine created from (%f, %f, %f) to (%f, %f, %f)",
                                                    pStpt.x, pStpt.y, pStpt.z, pEnpt.x, pEnpt.y, pEnpt.z);

                                                pStpt = pEnpt;
                                            }
                                            else if (key == L"VARC") 
                                            {
                                                double centerX, centerY, includedAngle;
                                                iss >> centerX >> centerY >> includedAngle;

                                                OdGePoint3d pCen(centerX, centerY, 0);
                                                OdGeVector3d vRad = pStpt - pCen;
                                                double dRad = vRad.length();
                                                double dStAng = OdGeVector3d::kXAxis.angleTo(vRad, OdGeVector3d::kZAxis);
                                                double dEnAng = dStAng + includedAngle;

                                                OdDbArcPtr pArc = OdDbArc::createObject();
                                                pArc->setCenter(pCen);
                                                pArc->setRadius(dRad);
                                                pArc->setStartAngle(dStAng);
                                                pArc->setEndAngle(dEnAng);

                                                pBTR->appendOdDbEntity(pArc);
                                                entities.push_back(pArc);

                                                pArc->transformBy(RotMat);
                                                pArc->transformBy(TransMat);

                                                double arcX = pCen.x + dRad * cos(dEnAng);
                                                double arcY = pCen.y + dRad * sin(dEnAng);
                                                pEnpt = OdGePoint3d(arcX, arcY, 0);

                                                icutPrintf(L"\nArc created with center (%f, %f, %f), radius: %f, start angle: %f, end angle: %f",
                                                    pCen.x, pCen.y, pCen.z, dRad, dStAng, dEnAng);
                                                pStpt = pEnpt;
                                                lastCommandWasArc = true;
                                            }
                                            else if (key == L"VCIRCLE")
                                            {
                                                double centerX, centerY, radius;
                                                iss >> centerX >> centerY >> radius;

                                                OdGePoint3d pCen(centerX, centerY, 0);

                                                OdDbCirclePtr pCircle = OdDbCircle::createObject();
                                                pCircle->setCenter(pCen);
                                                pCircle->setRadius(radius);

                                                pBTR->appendOdDbEntity(pCircle);
                                                entities.push_back(pCircle);

                                                pCircle->transformBy(RotMat);
                                                pCircle->transformBy(TransMat);

                                                icutPrintf(L"\nCircle created with center (%f, %f, %f) and radius: %f",
                                                    pCen.x, pCen.y, pCen.z, radius);
                                            }
                                        }
                                    }
                                    entities.clear();
                                    partFile.close();

                                   
                                }
                            }
                        }
                    }
                }
            }
        }
        if (currentPartProfile.is_open()) 
        {
            currentPartProfile.close();
        }
        layoutFile.close();
    }
}


//void NESTINPUT(OdEdCommandContext* pCmdCtx)
//{
//    AFX_MANAGE_STATE(AfxGetStaticModuleState());
//
//    OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
//    OdDbDatabasePtr pDatabase = pDbCmdCtx->database();
//    OdDbBlockTableRecordPtr pBTR = pDatabase->getModelSpaceId().openObject(OdDb::kForWrite);
//
//    std::vector<OdDbEntityPtr> entities;
//    std::ifstream profileFile("D:/NESTING/NL2023R1/Deliverables/Testapp/VC141/x86/Part4.prf");
//    std::ifstream transformationFile("D:/NESTING/NL2023R1/Deliverables/Testapp/VC141/x86/test.nop");
//
//    if (!profileFile.is_open())
//    {
//        icutPrintf(L"\nError: Unable to open profile input file.");
//        return;
//    }
//
//    if (!transformationFile.is_open())
//    {
//        icutPrintf(L"\nError: Unable to open transformation input file.");
//        return;
//    }
//
//    OdGePoint3d pStpt(0, 0, 0);
//    OdGePoint3d pEnpt(0, 0, 0);
//    bool lastCommandWasArc = false;
//
//    double dRotAng = 0.0;
//    double moveX = 0.0;
//    double moveY = 0.0;
//
//    std::string line;
//    while (std::getline(transformationFile, line))
//    {
//        std::istringstream iss(line);
//        std::string key;
//        double value;
//
//        if (iss >> key >> value)
//        {
//            if (key == "(ANGLE")
//            {
//                dRotAng = value;
//            }
//            else if (key == "(XMATRIX")
//            {
//                moveX = value;
//            }
//            else if (key == "(YMATRIX")
//            {
//                moveY = value;
//            }
//        }
//    }
//
//    icutPrintf(L"\nRead move values from file: X=%f, Y=%f", moveX, moveY);
//    OdGeMatrix3d translationMatrix;
//    translationMatrix.setToTranslation(OdGeVector3d(moveX, moveY, 0.0));
//
//
//    icutPrintf(L"\nRotated by angle from file: %f", dRotAng);
//    double rotationAngleRad = dRotAng * OdaPI / 180.0;
//    OdGeMatrix3d rotationMatrix;
//    rotationMatrix.setToRotation(rotationAngleRad, OdGeVector3d::kZAxis);
//
//
//    ---------------------------------------------------
//    while (std::getline(profileFile, line))
//    {
//        std::istringstream iss(line);
//        std::string key;
//
//
//        while (iss >> key)
//        {
//            if (key == "STARTPT")
//            {
//                double startX, startY;
//                iss >> startX >> startY;
//                pStpt = OdGePoint3d(startX, startY, 0);
//                lastCommandWasArc = false;
//            }
//            else if (key == "VLINE")
//            {
//                double endX, endY;
//                iss >> endX >> endY;
//                pEnpt = OdGePoint3d(endX, endY, 0);
//
//                OdDbLinePtr pLine = OdDbLine::createObject();
//                pLine->setStartPoint(pStpt);
//                pLine->setEndPoint(pEnpt);
//
//                pBTR->appendOdDbEntity(pLine);
//                entities.push_back(pLine);
//
//                lastCommandWasArc = false;
//
//                pLine->transformBy(translationMatrix);
//                pLine->transformBy(rotationMatrix);
//
//                icutPrintf(L"\nLine created from (%f, %f, %f) to (%f, %f, %f)",
//                    pStpt.x, pStpt.y, pStpt.z, pEnpt.x, pEnpt.y, pEnpt.z);
//
//                pStpt = pEnpt;
//            }
//            else if (key == "VARC")
//            {
//                double centerX, centerY, includedAngle;
//                iss >> centerX >> centerY >> includedAngle;
//
//                OdGePoint3d pCen(centerX, centerY, 0);
//                OdGeVector3d vRad = pStpt - pCen;
//                double dRad = vRad.length();
//                double dStAng = OdGeVector3d::kXAxis.angleTo(vRad, OdGeVector3d::kZAxis);
//                double dEnAng = dStAng + includedAngle;
//
//                OdDbArcPtr pArc = OdDbArc::createObject();
//                pArc->setCenter(pCen);
//                pArc->setRadius(dRad);
//                pArc->setStartAngle(dStAng);
//                pArc->setEndAngle(dEnAng);
//
//                pBTR->appendOdDbEntity(pArc);
//                entities.push_back(pArc);
//
//                double arcX = pCen.x + dRad * cos(dEnAng);
//                double arcY = pCen.y + dRad * sin(dEnAng);
//                pEnpt = OdGePoint3d(arcX, arcY, 0);
//
//                pArc->transformBy(translationMatrix);
//                pArc->transformBy(rotationMatrix);
//
//                icutPrintf(L"\nArc created with center (%f, %f, %f), radius: %f, start angle: %f, end angle: %f",
//                    pCen.x, pCen.y, pCen.z, dRad, dStAng, dEnAng);
//                pStpt = pEnpt;
//                lastCommandWasArc = true;
//            }
//        }
//    }
//
//    profileFile.close();
//    transformationFile.close();
//}