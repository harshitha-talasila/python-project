#include "StdAfx.h"
#include "OdaCommon.h"
#include "afxtoolbar.h"
#include "RxObjectImpl.h"
#include "DbBlockTableRecord.h"
#include "DbText.h"
#include "DbDictionary.h"
#include "DbCircle.h"
#include "DbGroup.h"
#include "DbSymUtl.h"
#include "DbBlockTable.h"
#include "DbViewportTable.h"
#include "DbViewport.h"
#include "DbLayerTable.h"
#include "DbAbstractViewTableRecord.h"
#include "DbVisualStyle.h"
#include "DbLayerTableRecord.h"
#include "DbSymUtl.h"
#include "../../inc/ArxCompat.h"
#include "DbRegAppTable.h"
#include "DbRegAppTableRecord.h"
#include "DbCommandContext.h"
#include "DbLinetypeTableRecord.h"
#include "Db3dPolyline.h"
#include "DbAlignedDimension.h"
#include "DbRotatedDimension.h"
#include "Db3dPolylineVertex.h"
#include "DbRadialDimensionLarge.h"
#include "DbRadialDimension.h"
#include "Db3PointAngularDimension.h"
#include"DbLeader.h"
#include "StringArray.h"
#include "DbEvalGraph.h"
#include"Dbtext.h"

#include "IRXSampleModule.h"
#include "IrxSampleDialog.h"
#include "IRXPreviewDialog.h"
#include "IcApi.h"
#include "windows.h"

#include "IcApDocManager.h"
#include "IcApDocumentIterator.h"
#include "IcApDocument.h"
#include "IcEdInputPointManager.h"
#include "IcadDbHostApplicationServices.h"
#include "IcGs.h"
#include "icedsds.h"
#include "IcColorSettings.h"

#include "sds.h"

#include "StaticRxObject.h"
#include "DbPolyline.h"
#include "DbSpLine.h"
#include "DbArc.h"
#include "Gi/GiDrawableImpl.h"
#include "Gi/GiWorldDraw.h"
#include "Gi/GiViewportDraw.h"

#include "Ge/GeExtents2d.h"
#include "DbUserIO.h"

#include "MultipleEntitiesJig.h"
#include "Db3dPolyline.h"
#include "cmath"
#include "windows.h"

#include "ios"
#include "iostream"
#include "fstream"
#include "sstream"

#include "OdaCommon.h"
#include "RxObject.h"
#include "DbBaseDatabase.h"
#include "DbDictionary.h"
#include "DbObjectIterator.h"
#include "DbText.h"
#include"Dbfcf.h"
#include"cmath"
#include"iomanip"
#include"DbPoint.h"
#include"OdString.h"
#include <string.h>
#include <filesystem>
#include "DbIdMapping.h"
#include "DbFiler.h"
#include"DbTable.h"
#include"GlobalVars.h"
#include"../LicCheck.h"

using namespace std;
namespace fs = std::filesystem;
ActGlobalVariables cGV;

int nLayNum = 0;
bool bInLay = false;
bool bInPt = false;
string sCurrPtNm, sBFPth, layoutName, line, sShPth, sShTok, sPtNm, sInsTk;
int nCurrPtInst = 0;
double dMatrX,dMatrY, dAng;
OdDbObjectId idLayer = OdDbObjectId::kNull;
size_t ExtPos;
OdString OdDwgFPth, OdPtFPth;
CString instancesValue;
CString OutArr[100][2];
std::wstring folderNameStr;

ODRX_DEFINE_DYNAMIC_MODULE(IRXSampleModule);
typedef void (*OdEdCommandFn)(OdEdCommandContext* pCmdCtx);

extern void NESTOUTPUT(OdEdCommandContext* pCmdCtx);
extern void NESTRESULTS(OdEdCommandContext* pCmdCtx);

class CommandImpl : public OdEdCommand
{
    OdEdCommandFn m_execute;
    OdString m_szCmdGroup;
    OdString m_szGlobalName;
    OdString m_szLocalName;
public:
    void execute(OdEdCommandContext* pCmdCtx) { m_execute(pCmdCtx); }
    const OdString globalName() const { return m_szGlobalName; }
    const OdString localName() const { return m_szGlobalName; }
    const OdString groupName() const { return m_szCmdGroup; }

    static OdEdCommandPtr createWrapper(OdEdCommandFn executeFn,
        const OdChar* szCmdGroup,
        const OdChar* szGlobalName)
    {
        OdSmartPtr<OdEdCommand> pRes = OdEdCommand::createObject(szCmdGroup, szGlobalName, szGlobalName, kUsePickset, executeFn, 0);
        return pRes;
    }
};


void IRXSampleModule::initApp()
{
    OdEdCommandStackPtr pCommands = ::odedRegCmds();

    pCommands->addCommand(CommandImpl::createWrapper(OdEdCommandFn(NESTOUTPUT), OdString(NESTING_OUTPUT_COMMANDS_GROUP), L"NESTOUTPUT"));
    pCommands->addCommand(CommandImpl::createWrapper(OdEdCommandFn(NESTRESULTS), OdString(NESTING_OUTPUT_COMMANDS_GROUP), L"NESTRESULTS"));
    return;
}

void IRXSampleModule::uninitApp()
{
    OdEdCommandStackPtr pCommands = ::odedRegCmds();
    pCommands->removeGroup(NESTING_OUTPUT_COMMANDS_GROUP);
}


OdDbObjectId CreateLayer(const string layoutName, OdDbDatabase* pDatabase)
{

    OdDbLayerTablePtr pLay = pDatabase->getLayerTableId().safeOpenObject(OdDb::kForWrite);
    std::string sLnm = layoutName;
    for (char& c : sLnm) {
        if (!isalnum(c) && c != '_')
        {
            c = '_';
        }
    }
    if (pLay->has(sLnm.c_str()))
    {
        idLayer = pLay->getAt(sLnm.c_str());
    }
    else
    {
        OdDbLayerTableRecordPtr pLayer = OdDbLayerTableRecord::createObject();
        pLayer->setName(sLnm.c_str());
        idLayer = pLay->add(pLayer);
    }    
    return idLayer;
}

struct InstanceDetails
{
    double dMatX;
    double dMatY;
    double dAng;
};

void ImportDwgAsBlock(OdString fNm, OdDbDatabasePtr pDb, double dMatX, double dMatY, double dAng, OdDbObjectId layerId)
{
    wstring str(fNm.c_str());
    size_t pos = str.find_last_of(L"\\/");
    str = str.substr(pos + 1, str.length());
    pos = str.find_last_of(L".");
    str = str.substr(0, pos);
    //----------------------------

    OdDbDatabasePtr pSrcDb = pDb->appServices()->readFile(fNm);
    OdDbObjectId obj = pDb->insert(L"*Model_Space", (OdString)str.c_str(), pSrcDb, true);
    OdDbBlockTableRecordPtr pBTR = pDb->getModelSpaceId().safeOpenObject(OdDb::kForWrite);
    OdDbBlockReferencePtr pBlkRef = OdDbBlockReference::createObject();
    OdGeMatrix3d transMat, rotMat;
    transMat.setToTranslation(OdGeVector3d(dMatX, dMatY, 0.0));
    double rotAng = dAng * OdaPI / 180.0;
    rotMat.setToRotation(rotAng, OdGeVector3d::kZAxis);
    pBlkRef->transformBy(rotMat);
    pBlkRef->transformBy(transMat);
    pBlkRef->setBlockTableRecord(obj);
    pBTR->appendOdDbEntity(pBlkRef);
    pBlkRef->setLayer(layerId);
}

void ProcessNopFile(const string nopFilePath, OdDbDatabasePtr pDb)
{
    ifstream nopFile(nopFilePath);
    if (!nopFile.is_open())
    {
        icutPrintf(L"\nFailed to open .nop file as: %S", nopFilePath.c_str());
        return;
    }
    size_t DotPos = nopFilePath.find_last_of(".");
    sBFPth = nopFilePath.substr(0, DotPos);
    size_t LasSlaPos = sBFPth.find_last_of("/\\");
    std::map<int, bool>numlay;
    if (LasSlaPos != string::npos)
    {
        sBFPth = sBFPth.substr(0, LasSlaPos);
    }  
    while (getline(nopFile, line))
    {
        istringstream iss(line);
        string token;
        iss >> token;
        if (token == "(PARTLIST")
        {
            break;
        }
        if (token == "(LAYOUT")
        {
            bInLay = true;
        }
        else if (token == "(NUMBER" && bInLay) 
        {
            iss >> nLayNum;
            layoutName = "Layer_" + std::to_string(nLayNum);
            if (!numlay[nLayNum])
            {
                idLayer = CreateLayer(layoutName, pDb);
                numlay[nLayNum] = true;
            }
        }
        else if (token == "(PART")
        {
            bInPt = true;
        }
        else if (token == "(SHEET" && bInLay)
        {           
            int sheetInstances = 0;
            while (getline(nopFile, line))
            {
                istringstream sheetLine(line);
                sheetLine >> sShTok;
                if (sShTok == "(NAME")
                {
                    getline(sheetLine, sShPth, '(');
                    getline(sheetLine, sShPth, ')');
                    sShPth = sShPth.substr(1);
                    sShPth.erase(sShPth.begin(), find_if(sShPth.begin(), sShPth.end(), [](int ch)
                        {
                            return !isspace(ch);
                        }));
                    if (!sShPth.empty() && sShPth.back() == ')')
                    {
                        sShPth.pop_back();
                    }
                    ExtPos = sShPth.find_last_of('.');
                    if (ExtPos != string::npos)
                    {
                        sShPth = sShPth.substr(0, ExtPos) + ".dwg";
                    }
                    OdDwgFPth = sShPth.c_str();
                    if (filesystem::exists(OdDwgFPth.c_str()))
                    {
                        ImportDwgAsBlock(OdDwgFPth, pDb, 0.0, 0.0, 0.0, idLayer);
                    }
                    break;
                }
            }
        }
        else if (token == ")")
        {
            bInLay = false;
            bInPt = false;
        }
        else if (token == "(NAME" && bInPt)
        {
            iss >> ws;
            getline(iss, sPtNm, ')');
            ExtPos = sPtNm.find_last_of('.');
            if (ExtPos != string::npos)
            {
                sPtNm = sPtNm.substr(0, ExtPos) + ".dwg";
            }
            sCurrPtNm = sPtNm;
        }
        else if (token == "(INSTANCES" && bInPt)
        {
            iss >> nCurrPtInst;
            for (int i = 0; i < nCurrPtInst; ++i)
            {
                while (getline(nopFile, line))
                {
                    istringstream instLine(line);
                    instLine >> sInsTk;
                    if (sInsTk == "(XMATRIX")
                    {
                        instLine >> dMatrX;
                    }
                    else if (sInsTk == "(YMATRIX")
                    {
                        instLine >> dMatrY;
                    }
                    else if (sInsTk == "(ANGLE")
                    {
                        instLine >> dAng;
                    }
                    else if (sInsTk == ")")
                    {
                        OdPtFPth = sCurrPtNm.c_str();
                        if (filesystem::exists(OdPtFPth.c_str()))
                        {
                            ImportDwgAsBlock(OdPtFPth, pDb, dMatrX, dMatrY, dAng, idLayer);
                        }
                        break;
                    }
                }
            }
        }
    }
}

void NESTOUTPUT(OdEdCommandContext* pCmdCtx)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
    OdDbDatabasePtr pDb = pDbCmdCtx->database();

    ////-------------------------------------------
    ActDatabaseInitialize mydatabase;
    mydatabase.DWGModelspace(true);
    if (mydatabase.val == 80086)  {  return;  }
    ////-------------------------------------------

    int retVal = RTERROR;
    IcString cuiPath;
    retVal = icedGetVar(L"ACTNESTPATH", cuiPath);
    CString csCuiPath(static_cast<const wchar_t*>(cuiPath));
   // icutPrintf(L"CUIPATH value: %s", static_cast<const wchar_t*>(csCuiPath));

    std::wstring stdFilePath1 = static_cast<const wchar_t*>(csCuiPath);
 
   //--------------------------------------------

    fs::path lastFolderPath(stdFilePath1);
    bool bPtFExist = fs::exists(lastFolderPath / L"parts.txt");
    bool bStFExist = fs::exists(lastFolderPath / L"sheets.txt");
    bool bSetFExist = fs::exists(lastFolderPath / L"settings.txt");

    if (!bPtFExist || !bStFExist || !bSetFExist)
    {
        icutPrintf(L"\nError: Required file is missing.");
        if (!bPtFExist)
        {
            icutPrintf(L"\nPart Data Not Found, Please Select Parts..");
        }
        if (!bStFExist)
        {
            icutPrintf(L"\nSheet Data Not Found, Please Select Sheets..");
        }
        if (!bSetFExist)
        {
            icutPrintf(L"\nSettings Data Not Found, Please Enable Settings");
        }
        return;
    }

    std::wstring lastFolderPathStr(csCuiPath);
    auto lastBackslashIter = std::find(lastFolderPathStr.rbegin(), lastFolderPathStr.rend(), L'\\');
    if (lastBackslashIter != lastFolderPathStr.rend())
    {
        ptrdiff_t lastBackslashIndex = lastFolderPathStr.rend() - lastBackslashIter - 1;
        folderNameStr = lastFolderPathStr.substr(lastBackslashIndex + 1);
    }
    // icutPrintf(L"The value of folderNameStr is: %ls\n", folderNameStr.c_str());

    fs::path nipFilePath = stdFilePath1;
    nipFilePath /= folderNameStr;
    nipFilePath.replace_extension(L".nip");
    wofstream nipFile(nipFilePath, ios::trunc);
    // Convert fs::path to std::wstring
    std::wstring wstrNipFilePath = nipFilePath.wstring();

    // Print nipFilePath using icutPrintf
   // icutPrintf(L"NiP File Path: %s", wstrNipFilePath.c_str());
    //---------------value to registry--------------

    //------------------------------------------------

    wstringstream Cs;
    Cs << L"    (SETTINGS\n";
    Cs << L"        (NEST_TYPE NORMAL)\n";
    Cs << L"        (LANGUAGE ENGLISH)\n";
    Cs << L"        (DIRECTORIES\n";
    Cs << L"            (DATA     " << stdFilePath1 << L")\n";
    Cs << L"            (OUTPUT   " << stdFilePath1 << L")\n";
    Cs << L"            (TEMPORARY " << stdFilePath1 << L")\n";
    Cs << L"        )\n";
    Cs << L"        (FILES\n";
    Cs << L"            (OUTPUT\n";
    Cs << L"				(FORMAT UNIFIED)\n";
    Cs << L"				(RESULT " << folderNameStr << L".nop)\n";
    Cs << L"				(ERROR  " << folderNameStr << L".err)\n";
    Cs << L"			)\n";
    Cs << L"			(MESSAGE  )\n";
    Cs << L"		)\n";
    Cs << L"	)\n";

    CString path = csCuiPath + L"\\settings.txt";

    std::wifstream settingsFile(path);
    if (!settingsFile.is_open())
    {
        icutPrintf(L"\nError opening settings.txt file for reading.");
        return;
    }
    Cs << L"    (PARAMETERS\n";
    std::wstring line;
    bool firstLine = true;
    while (std::getline(settingsFile, line))
    {
        size_t lastUnderscorePos = line.find_last_of('_');
        std::wstring parameter = line.substr(0, lastUnderscorePos);
        std::wstring value = line.substr(lastUnderscorePos + 1);
        std::wstringstream formattingSpace;
        formattingSpace << std::setw(30 - parameter.length()) << L"";
        Cs << L"\t\t(" << parameter << formattingSpace.str() << value << L")\n";
        firstLine = false;
    }
    Cs << L"	)\n";
    settingsFile.close();

    //----------------------------------------

    fs::path partsFilePath = stdFilePath1;
    partsFilePath.append(L"parts.txt");

    std::wifstream partsFile(partsFilePath);
    if (!partsFile.is_open())
    {
        icutPrintf(L"\nError opening Parts file.");
        return;
    }

    Cs << L"    (PARTLIST\n";
    const wstring SHAPE = L"X";
    int nFitType = 2;
    int nPriority = 1;
    wstring sGrain = L"NONE";
    wstring sRAng = L"BY-STEP-METHOD";
    double dSAng = 1.0;
    wstring partName;
    wstring priorityValue, minValue, maxValue, grainValue, stepAngleValue, rotAngleValue, fitTypeValue, Qty;

    map<wstring, vector<wstring>> vGpts;
    map<wstring, int> groupCounts;
    map<wstring, double> groupMaxValues;
    wstring GroupValue;
    map<wstring, double> groupMinQtyValues;
    map<wstring, double> groupMinOfMaxValues;

    int nPCnt = 1;
    while (getline(partsFile, line))
    {
        wstring wstrLine(line.begin(), line.end());
        size_t FPos = wstrLine.find(L'-');
        size_t SPos = wstrLine.find(L'-', FPos + 1);
        size_t TPos = wstrLine.find(L'-', SPos + 1);

        partName = wstrLine.substr(FPos + 1, TPos - FPos - 1);

        size_t minPos = wstrLine.find(L"Min_") + 4;
        size_t maxPos = wstrLine.find(L"_", minPos);
        minValue = wstrLine.substr(minPos, maxPos - minPos);

        size_t maxPos1 = maxPos + 1;
        size_t endPos = wstrLine.find(L"_", maxPos1);
        maxValue = wstrLine.substr(maxPos1, endPos - maxPos1);

        size_t grainPos = endPos + 1;
        size_t nextPos = wstrLine.find(L"_", grainPos);
        grainValue = wstrLine.substr(grainPos, nextPos - grainPos);

        size_t stepAnglePos = nextPos + 1;
        size_t nextNextPos = wstrLine.find(L"_", stepAnglePos);
        stepAngleValue = wstrLine.substr(stepAnglePos, nextNextPos - stepAnglePos);

        size_t rotAnglePos = nextNextPos + 1;
        size_t rotAngleEndPos = wstrLine.find_first_not_of(L"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_-", rotAnglePos);
        rotAngleValue = wstrLine.substr(rotAnglePos, rotAngleEndPos - rotAnglePos);

        if (!rotAngleValue.empty() && rotAngleValue.back() == L'_')
        {
            rotAngleValue.pop_back();
        }
        size_t fitTypePos = rotAngleEndPos;
        size_t fitTypeEndPos = wstrLine.find(L"_", fitTypePos);
        fitTypeValue = wstrLine.substr(fitTypePos, fitTypeEndPos - fitTypePos);

        size_t priorityPos = fitTypeEndPos + 1;
        size_t priorityEndPos = wstrLine.find(L"_", priorityPos);
        priorityValue = wstrLine.substr(priorityPos, priorityEndPos - priorityPos);

        //----------------------------------------------------

        size_t GroupPos = priorityEndPos + 1;
        size_t GroupEndPos = wstrLine.find(L"_", GroupPos);
        GroupValue = wstrLine.substr(GroupPos, GroupEndPos - GroupPos);

        size_t QtyPos = GroupEndPos + 1;
        size_t QtyEndPos = wstrLine.find(L"_", QtyPos);
        Qty = wstrLine.substr(QtyPos, QtyEndPos - QtyPos);

        groupCounts[GroupValue]++;
        vGpts[GroupValue].push_back(partName);
        vGpts[GroupValue].push_back(maxValue);
        vGpts[GroupValue].push_back(Qty);

        Cs << L"		(PART\n";
        Cs << L"			(NAME                  " << partName << L")\n";
        Cs << L"			(MINIMUM               " << minValue << L")\n";
        Cs << L"			(MAXIMUM               " << maxValue << L")\n";
        Cs << L"			(GRAIN                 " << grainValue << L")\n";
        Cs << L"			(STEP_ANGLE            " << fixed << setprecision(6) << stepAngleValue << L")\n";
        Cs << L"			(ROTATION_ANGLE_METHOD " << rotAngleValue << L")\n";
        Cs << L"			(FIT_TYPE              " << fitTypeValue << L")\n";
        Cs << L"			(PRIORITY              " << priorityValue << L")\n";
        Cs << L"		)\n";
        nPCnt++;
    }

    for (const auto& pair : groupCounts)
    {
        const wstring& GroupValue = pair.first;
        int count = pair.second;
        int groupIntValue = stoi(GroupValue);

        if (groupIntValue > 0)
        {
            double maxVal = numeric_limits<double>::min();
            double minQty = numeric_limits<double>::max();
            double minOfMaxVal = numeric_limits<double>::max();

            if (vGpts.find(GroupValue) != vGpts.end())
            {
                auto parts = vGpts[GroupValue];
                for (size_t i = 1; i < parts.size(); i += 3)
                {
                    double val = stod(parts[i]);
                    if (val > maxVal)
                    {
                        maxVal = val;
                    }
                    minQty = min(minQty, stod(parts[i + 1]));
                    minOfMaxVal = min(minOfMaxVal, val);
                }
            }
            groupMinOfMaxValues[GroupValue] = minOfMaxVal;
            groupMaxValues[GroupValue] = maxVal;
            groupMinQtyValues[GroupValue] = minQty;

            fs::path outputFile = stdFilePath1;
            outputFile.append(GroupValue + L".grp");
            wofstream outFile(outputFile, ios::trunc);
            if (outFile.is_open())
            {
                outFile << count << endl;
                auto parts = vGpts[GroupValue];
                for (size_t i = 0; i < parts.size(); i += 3)
                {
                    outFile << parts[i] << L" " << parts[i + 2] << endl; 
                }
                outFile.close();
            }
        }
    }
    for (const auto& pair : groupCounts)
    {
        const wstring& GroupValue = pair.first;
        int count = pair.second;
        int groupIntValue = stoi(GroupValue);

        if (groupIntValue > 0)
        {
            fs::path grpFile = stdFilePath1;
            grpFile.append(GroupValue + L".grp");

            if (fs::exists(grpFile))
            {
                double minQty = groupMinQtyValues[GroupValue];
                double maxVal = groupMaxValues[GroupValue];
                double minOfMaxVal = groupMinOfMaxValues[GroupValue];

                Cs << L"		(PART\n";
                Cs << L"			(NAME                  " << GroupValue << L".grp)\n";
                Cs << L"			(MINIMUM               " << minQty << L")\n";
                Cs << L"			(MAXIMUM               " << minOfMaxVal << L")\n";
                Cs << L"			(GRAIN                 " << grainValue << L")\n";
                Cs << L"			(STEP_ANGLE            " << fixed << setprecision(6) << stepAngleValue << L")\n";
                Cs << L"			(ROTATION_ANGLE_METHOD " << rotAngleValue << L")\n";
                Cs << L"			(FIT_TYPE              " << fitTypeValue << L")\n";
                Cs << L"			(PRIORITY              " << priorityValue << L")\n";
                Cs << L"			(GROUP              " << L" 1)\n";
                Cs << L"		)\n";
            }
        }
    }
    Cs << L"	)\n";
    partsFile.close();

    //--------------------------------------------

    fs::path sheetfilapath = stdFilePath1;
    sheetfilapath.append(L"sheets.txt");

    wifstream sheetsfile(sheetfilapath);
    if (!sheetsfile.is_open())
    {
        icutPrintf(L"\nError opening Sheets file.");
        return;
    }
    Cs << L"	(SHEETLIST\n";

    wstring wsDir = L"Y";
    wstring wsCorner = L"LL";
    wstring wsGrain = L"NONE";

    double dScoll = 0.0;
    double dReso = 1.0;

    int nSCnt = 1;
    while (getline(sheetsfile, line))
    {
        wstring wstrLine1(line.begin(), line.end());
        size_t FPos = wstrLine1.find(L'-');
        size_t SPos = wstrLine1.find(L'-', FPos + 1);
        size_t TPos = wstrLine1.find(L'-', SPos + 1);
        wstring partName = wstrLine1.substr(FPos + 1, TPos - FPos - 1);

        const wstring qtySubstring = L"Qty_";
        size_t qtyPos = wstrLine1.find(qtySubstring);
        size_t qtyEndPos = wstrLine1.find_first_not_of(L"0123456789", qtyPos + qtySubstring.size());
        int quantity = stoi(wstrLine1.substr(qtyPos + qtySubstring.size(), qtyEndPos - qtyPos - qtySubstring.size()));

        const wstring dirSubstring = L"_";
        size_t dirPos = qtyEndPos + 1;
        size_t dirEndPos = wstrLine1.find(dirSubstring, dirPos);
        wstring directionValue = wstrLine1.substr(dirPos, dirEndPos - dirPos);

        size_t cornerPos = dirEndPos + dirSubstring.size();
        size_t cornerEndPos = wstrLine1.find(dirSubstring, cornerPos);
        wstring cornerValue = wstrLine1.substr(cornerPos, cornerEndPos - cornerPos);

        size_t grainPos = cornerEndPos + dirSubstring.size();
        size_t grainEndPos = wstrLine1.find(dirSubstring, grainPos);
        wstring grainValue = wstrLine1.substr(grainPos, grainEndPos - grainPos);

        size_t resoPos = wstrLine1.rfind(L"_");
        double dResoFromLine = stod(wstrLine1.substr(resoPos + 1));

        Cs << L"		(SHEET\n";
        Cs << L"			(NAME     " << partName << L")\n";
        Cs << L"			(QUANTITY " << quantity << L")\n";
        Cs << L"			(DIRECTION " << directionValue << L")\n";
        Cs << L"			(CORNER    " << cornerValue << L")\n";
        Cs << L"			(GRAIN    " << grainValue << L")\n";
        // Cs << L"			(RESOLUTION " << fixed << setprecision(6) << dResoFromLine << L")\n";
        Cs << L"		)\n";
        nSCnt++;
    }
    Cs << L"	)\n";

    sheetsfile.close();
    nipFile << Cs.str();
    nipFile.close();


    //-------------------------------------------------
    icutPrintf(L"\nNESTING IS IN PROGRESS....");

    //---------------------------------------
    //--------Data from registory------------
   
    std::wstring wstrCuiPath(csCuiPath.GetString());
    wstring wsProjectName = folderNameStr;
    wstrCuiPath += L"\\" + wsProjectName + L".nop";
    //icutPrintf(L"The value of folderNameStr is: %ls\n", folderPath1.c_str()); 

    string sFolderPath(wstrCuiPath.begin(), wstrCuiPath.end());

    //---------------------------------------------

    char bufr[1024] = { 0 };
    DWORD ret = GetModuleFileNameA(NULL, bufr, sizeof(bufr));
    string dsa = string(bufr);
    string::size_type pos = dsa.find_last_of("\\/");
    string exePath = dsa.substr(0, pos) + "\\NestWin.exe";
    wstring rpath(exePath.begin(), exePath.end());
    std::replace(wstrNipFilePath.begin(), wstrNipFilePath.end(), L'\\', L'/');
    wstring ws_parms = wstrNipFilePath + L" -S -D 11EFD3C5F46A6AE9B9C69EF8306779DE5564F021FCBF6ECF019DF91C3E3D8R59F030BF667B36AF233901";
    SHELLEXECUTEINFO ShExecInfo = { 0 };
    ShExecInfo.cbSize = sizeof(SHELLEXECUTEINFO);
    ShExecInfo.fMask = SEE_MASK_NOCLOSEPROCESS;
    ShExecInfo.hwnd = NULL;
    ShExecInfo.lpVerb = NULL;
    ShExecInfo.lpFile = rpath.c_str();
    ShExecInfo.lpParameters = ws_parms.c_str();
    ShExecInfo.lpDirectory = NULL;
    ShExecInfo.nShow = SW_SHOW;
    ShExecInfo.hInstApp = NULL;
    ShellExecuteEx(&ShExecInfo);
    WaitForSingleObject(ShExecInfo.hProcess, INFINITE);
    CloseHandle(ShExecInfo.hProcess);
    ProcessNopFile(sFolderPath, pDb);
    icedPostCommand(L"(command \"z\" \"e\")");
    CIrxSampleDialog myDlg;  
    if (myDlg.DoModal() == IDOK)
    {
        ;
    }
}
             
void NESTRESULTS(OdEdCommandContext* pCmdCtx)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
    OdDbDatabasePtr pDb = pDbCmdCtx->database();
    OdDbBlockTableRecordPtr pBTR = pDb->getModelSpaceId().safeOpenObject(OdDb::kForWrite);

    //-------------------------------------------
    ActDatabaseInitialize mydatabase;
    mydatabase.DWGModelspace(true);
    if (mydatabase.val == 80086) { return; }
    //-------------------------------------------


    int retVal = RTERROR;
    IcString cuiPath;
    retVal = icedGetVar(L"ACTNESTPATH", cuiPath);
    CString csCuiPath(static_cast<const wchar_t*>(cuiPath));
    //icutPrintf(L"CUIPATH value: %s", static_cast<const wchar_t*>(csCuiPath));
    //---------------------------------------
    //--------Data from registry------------

    //----------------------------------------

    std::wstring lastFolderPathStr(csCuiPath);

    std::wstring folderNameStr;
    auto lastBackslashIter = std::find(lastFolderPathStr.rbegin(), lastFolderPathStr.rend(), L'\\');
    if (lastBackslashIter != lastFolderPathStr.rend())
    {
        ptrdiff_t lastBackslashIndex = lastFolderPathStr.rend() - lastBackslashIter - 1;
        folderNameStr = lastFolderPathStr.substr(lastBackslashIndex + 1);
    }
    std::wstring wstrCuiPath(csCuiPath.GetString());
    wstring wsProjectName = folderNameStr;
    wstrCuiPath += L"\\" + wsProjectName + L".nop";
   
    string sFolderPath(wstrCuiPath.begin(), wstrCuiPath.end());
    std::wstring stdFilePath1 = static_cast<const wchar_t*>(csCuiPath);

    fs::path nipFilePath = stdFilePath1;
    nipFilePath /= folderNameStr;
    nipFilePath.replace_extension(L".nip");
    wofstream nipFile(nipFilePath, ios::trunc);
    // Convert fs::path to std::wstring
    std::wstring wstrNipFilePath = nipFilePath.wstring();

    // Print nipFilePath using icutPrintf
   // icutPrintf(L"NiP File Path: %s", wstrNipFilePath.c_str());

    struct stat buffer;
    if (stat(sFolderPath.c_str(), &buffer) != 0)
    {
        //---------------------------------------------

        char bufr[1024] = { 0 };
        DWORD ret = GetModuleFileNameA(NULL, bufr, sizeof(bufr));
        string dsa = string(bufr);
        string::size_type pos = dsa.find_last_of("\\/");
        string exePath = dsa.substr(0, pos) + "\\NestWin.exe";
        wstring rpath(exePath.begin(), exePath.end());
        std::replace(wstrNipFilePath.begin(), wstrNipFilePath.end(), L'\\', L'/');
        wstring ws_parms = wstrNipFilePath + L" -S -D 11EFD3C5F46A6AE9B9C69EF8306779DE5564F021FCBF6ECF019DF91C3E3D8R59F030BF667B36AF233901";
        SHELLEXECUTEINFO ShExecInfo = { 0 };
        ShExecInfo.cbSize = sizeof(SHELLEXECUTEINFO);
        ShExecInfo.fMask = SEE_MASK_NOCLOSEPROCESS;
        ShExecInfo.hwnd = NULL;
        ShExecInfo.lpVerb = NULL;
        ShExecInfo.lpFile = rpath.c_str();
        ShExecInfo.lpParameters = ws_parms.c_str();
        ShExecInfo.lpDirectory = NULL;
        ShExecInfo.nShow = SW_SHOW;
        ShExecInfo.hInstApp = NULL;
        ShellExecuteEx(&ShExecInfo);
        WaitForSingleObject(ShExecInfo.hProcess, INFINITE);
        CloseHandle(ShExecInfo.hProcess);
        //---------------------------------------------
    }

    CIrxSampleDialog myDlg;
    if (myDlg.DoModal() == IDOK)
    {
        ;
    }
    int nResult = AfxMessageBox(L"Do you want to save the results?", MB_YESNO | MB_ICONQUESTION);
    if (nResult == IDYES)
    {
        OdGePoint3d pt;
        int ret = icedGetPoint(NULL, L"\nSelect Table Location:", pt);
        if (ret != RTNORM)
        {
            icutPrintf(L"Error: Failed to get point for table creation.\n");
            return;
        }

        OdDbTablePtr pTable = OdDbTable::createObject();
        if (pTable.isNull())
        {
            icutPrintf(L"Error: Failed to create table object.\n");
            return;
        }
        pTable->setPosition(pt);
        pTable->setNumColumns(5);
        IcString cuiPath;
        int retVal = icedGetVar(L"ACTNESTPATH", cuiPath);
        CString csCuiPath(static_cast<const wchar_t*>(cuiPath));
        //icutPrintf(L"CUIPATH value: %s", static_cast<const wchar_t*>(csCuiPath));

        CString originalCsCuiPath = csCuiPath;
        CString csPath;
        csCuiPath += L"/parts.txt";
        csPath = csCuiPath;

        pTable->setTextString(0, 0, L"sno");
        pTable->setTextString(0, 1, L"part name");
        pTable->setTextString(0, 2, L"max qty");
        pTable->setTextString(0, 3, L"min qty");
        pTable->setTextString(0, 4, L"nested qty");

        int nRow = 1;
        CString line, csSno, csPart, csCount, csMax;
        CStdioFile file;
        if (file.Open(csPath, CFile::modeRead))
        {
            while (file.ReadString(line))
            {
                int nTokenPos = 0, nCP = 0;
                CString strToken = line.Tokenize(_T("-_"), nTokenPos);
                while (!strToken.IsEmpty())
                {
                    if (nCP == 0)
                        csSno = strToken;
                    else if (nCP == 2 && strToken.Left(4) == "part")
                        csPart = strToken;
                    else if (nCP == 4)
                        csCount = strToken;
                    else if (nCP == 5)
                        csMax = strToken;
                    strToken = line.Tokenize(_T("-_"), nTokenPos);
                    nCP++;
                }
                pTable->insertRows(nRow, 1);
                pTable->setTextString(nRow, 0, OdString(csSno.GetString()));
                pTable->setTextString(nRow, 1, OdString(csPart.GetString()));
                pTable->setTextString(nRow, 2, OdString(csCount.GetString()));
                pTable->setTextString(nRow, 3, OdString(csMax.GetString()));
                pTable->setTextString(nRow, 4, L"");
                nRow++;
            }
            file.Close();
        }
        double columnWidth = 150;
        double rowHeight = 15;
        pTable->setColumnWidth(columnWidth);
        pTable->setRowHeight(rowHeight);
        double textHeight = 5.0;
        pTable->setTextHeight(textHeight);
        for (int col = 0; col < 5; ++col)
        {
            pTable->setAlignment(0, col, OdDb::kMiddleCenter);
        }
        int numRows = pTable->numRows();
        for (int i = 1; i < numRows && i - 1 < cGV.g_nestedQtyValues.size(); ++i)
        {
            pTable->setTextString(i, 4, OdString(cGV.g_nestedQtyValues[i - 1].GetString()));
        }
        cGV.g_nestedQtyValues.clear();
        OdDbObjectId tableId = pBTR->appendOdDbEntity(pTable);
        OdDbLayerTablePtr pLayerTable = pDb->getLayerTableId().safeOpenObject(OdDb::kForWrite);
        if (!pLayerTable.isNull())
        {
            OdDbLayerTableRecordPtr pLayerRecord = OdDbLayerTableRecord::createObject();
            pLayerRecord->setName(L"TableLayer");
            pLayerRecord->setIsFrozen(false);
            pLayerRecord->setIsOff(false);
        }
        pBTR->upgradeOpen();
    }
}