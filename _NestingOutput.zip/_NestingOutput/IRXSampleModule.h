#ifndef IRXTESTMODULE_INCLUDED
#define IRXTESTMODULE_INCLUDED

#include "RxDynamicModule.h"
#include "Ed/EdCommandStack.h"
#include "StaticRxObject.h"
#include "DbLine.h"
#include "DbBlockReference.h"

#include "gs/Gs.h"
#define NESTING_OUTPUT_COMMANDS_GROUP  "Nesting Output"


class IRXSampleModule : public OdRxModule
{
public:

	void initApp();
	void uninitApp();

};

#endif //	IRXTESTMODULE_INCLUDED
