// IRXDialog.cpp : implementation file
//
#include "stdafx.h"

#include "OdaCommon.h"
#include "DbEntity.h"
#include "Gs/GsDefs.h"

#include "IRXPreviewDialog.h"
#include <IcApi.h>

// CIrxPreviewDialog dialog

IMPLEMENT_DYNAMIC(CIrxPreviewDialog, CDialog)
CIrxPreviewDialog::CIrxPreviewDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CIrxPreviewDialog::IDD, pParent)
{
}

CIrxPreviewDialog::~CIrxPreviewDialog()
{
}

void CIrxPreviewDialog::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CIrxPreviewDialog, CDialog)
    ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, OnBnClickedCancel)
	ON_BN_CLICKED(IDC_SHOWPREVIEW, OnBnClickedShowPreview)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CIrxPreviewDialog message handlers

static bool regen = false;
void CIrxPreviewDialog::OnBnClickedOk()
{
	regen = false;
	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}

void CIrxPreviewDialog::OnBnClickedCancel()
{
	regen = false;
    // TODO: Add your control notification handler code here
	CDialog::OnCancel();
}

void CIrxPreviewDialog::OnBnClickedShowPreview()
{
	CPaintDC dc(this);
	CRect rect;

	GetClientRect(&rect);
	dc.FillSolidRect(&rect, RGB(0,0,0));

	int prevMode = dc.SetMapMode(MM_ANISOTROPIC);
	CPoint prevOrg = dc.GetWindowOrg();
	CSize prevExt = dc.GetWindowExt();
	dc.SetWindowOrg(CPoint(rect.TopLeft().x, rect.BottomRight().y));
	dc.ScaleWindowExt(1, 1, -1, 1);

	OdGsDCRectDouble odrect( rect.left, rect.right, rect.top, rect.bottom);

	icDrawEntitiesToDC(dc.m_hDC, odrect, m_Entities ,ODRGB( 0,0,0));

	dc.SetWindowExt(prevExt);
	dc.SetWindowOrg(prevOrg);
	dc.SetMapMode(prevMode);

	regen = true;
}

void CIrxPreviewDialog::SetEntities(OdDbEntityPtrArray entities)
{
	m_Entities = entities;
}

void CIrxPreviewDialog::OnPaint()
{
	if (regen == true)
		OnBnClickedShowPreview();
}