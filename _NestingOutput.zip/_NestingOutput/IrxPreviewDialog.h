#pragma once


// CIrxPreviewDialog dialog

#include "resource.h"
class CIrxPreviewDialog : public CDialog
{
	DECLARE_DYNAMIC(CIrxPreviewDialog)

public:
	CIrxPreviewDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CIrxPreviewDialog();

	void SetEntities(OdDbEntityPtrArray entities);

// Dialog Data
	enum { IDD = IDD_DIALOG2 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedOk();
    afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedShowPreview();

protected :
	OdDbEntityPtrArray m_Entities;
	afx_msg void OnPaint( );
};
