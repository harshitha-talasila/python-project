

#include "stdafx.h"
#include "IRXSampleDialog.h"
#include <iterator>
#include"GlobalVars.h"


// CIrxSampleDialog dialog

IMPLEMENT_DYNAMIC(CIrxSampleDialog, CDialog)
CIrxSampleDialog::CIrxSampleDialog(CWnd* pParent /*=NULL*/)
    : CDialog(CIrxSampleDialog::IDD, pParent) 
{
}

CIrxSampleDialog::~CIrxSampleDialog()
{
}


BOOL CIrxSampleDialog::OnInitDialog()
{


    CDialog::OnInitDialog();
    HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_ICON1));
    SetIcon(hIcon, FALSE);

    m_EditBox.SubclassDlgItem(IDC_EDIT1, this);
    m_EditBox.SetWindowText(_T(""));

    CWnd* pwnd = GetDlgItem(IDC_STATIC);
    CFont* pfont = pwnd->GetFont();
    LOGFONT lf;
    pfont->GetLogFont(&lf);
    lf.lfWeight = FW_ULTRABOLD;
    lf.lfHeight = 40;
    CFont m_font;
    m_font.CreateFontIndirect(&lf);
    pwnd->SetFont(&m_font);

    ListView_SetExtendedListViewStyle(::GetDlgItem(m_hWnd, IDC_LIST1), LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
    m_ListCtrl.ModifyStyle(NULL, LVS_SINGLESEL, 0);
    m_ListCtrl.InsertColumn(0, L"sno", LVCFMT_LEFT, 40);
    m_ListCtrl.InsertColumn(1, L"Part Name", LVCFMT_LEFT, 75);
    m_ListCtrl.InsertColumn(2, L"Min Qty", LVCFMT_LEFT, 75);
    m_ListCtrl.InsertColumn(3, L"Max Qty", LVCFMT_LEFT, 75);
    m_ListCtrl.InsertColumn(4, L"Nested Qty", LVCFMT_LEFT, 80);

    nRow = 0;
    int nR = 0;

    //-----------------------------------------
    IcString cuiPath;
    int retVal = icedGetVar(L"ACTNESTPATH", cuiPath);
    CString csCuiPath(static_cast<const wchar_t*>(cuiPath));
    //icutPrintf(L"CUIPATH value: %s", static_cast<const wchar_t*>(csCuiPath));

    CString originalCsCuiPath = csCuiPath;
    CString csPath;
    csCuiPath += L"/parts.txt";
    csPath = csCuiPath;

    std::wstring stdFilePath1 = static_cast<const wchar_t*>(originalCsCuiPath);
    std::wstring folderNameStr;
    std::wstring lastFolderPathStr(originalCsCuiPath);
    auto lastBackslashIter = std::find(lastFolderPathStr.rbegin(), lastFolderPathStr.rend(), L'\\');
    if (lastBackslashIter != lastFolderPathStr.rend())
    {
        ptrdiff_t lastBackslashIndex = lastFolderPathStr.rend() - lastBackslashIter - 1;
        folderNameStr = lastFolderPathStr.substr(lastBackslashIndex + 1);
    }

    std::wstring wstrCuiPath(originalCsCuiPath.GetString());
    wstring wsProjectName = folderNameStr;
    wstrCuiPath += L"\\" + wsProjectName + L".nop";

    CString csFilePath(wstrCuiPath.c_str());
   // icutPrintf(L"File Path11: %s", static_cast<const wchar_t*>(csFilePath));

    int abc;
    CString csFstr;
    CStdioFile file1;
    CStdioFile file;
    if (file.Open(csPath, CFile::modeRead))
    {
        CString line;
        CString csSno, csPart, csCount,csMax;
        while (file.ReadString(line))
        {
            int nTokenPos = 0, nCP = 0;
            CString strToken = line.Tokenize(_T("-_"), nTokenPos);
            while (!strToken.IsEmpty())
            {
                if (nCP == 0)
                    csSno = strToken;
                else if (nCP == 2 && strToken.Left(4) == "part")
                    csPart = strToken;
                else if (nCP == 4)
                    csCount = strToken;
                else if (nCP == 5) 
                    csMax = strToken;
                strToken = line.Tokenize(_T("-_"), nTokenPos);
                nCP++;
            }
            abc = m_ListCtrl.InsertItem(nRow, L"");
            m_ListCtrl.SetItemText(abc, 0, csSno);
            m_ListCtrl.SetItemText(abc, 1, csPart);
            m_ListCtrl.SetItemText(abc, 2, csCount);
            m_ListCtrl.SetItemText(abc, 3, csMax);
            PtsArr[nRow][0] = csPart;
            PtsArr[nRow][1] = csCount;
            nRow++;
        }
        file.Close();
    }
 

    cGV.vSnVals.clear();
    cGV.vUtVals.clear();
    //-------------------------------------------
    CString line, csSnm, csSNum, csUtil;
    bool isInSheet = false;
    bool isInPartList = false;
    if (file1.Open(csFilePath, CFile::modeRead))
    {
        while (file1.ReadString(line))
        {
            if (line.Find(L"(SHEET") != -1)
            {
                isInSheet = true;
            }
            if (isInSheet)
            {
                int namePos = line.Find(L"(NAME");
                if (namePos != -1)
                {
                    int nameStart = line.Find(L"(NAME");
                    int nameEnd = line.Find(L".prf)");
                    if (nameStart != -1 && nameEnd != -1)
                    {
                        csSnm = line.Mid(nameStart, nameEnd - nameStart + 4);
                        CString csTempSN;
                        int startPos = csSnm.Find(L"sheet") + 5;
                        int endPos = csSnm.Find(L".prf") - 1;
                        csTempSN = csSnm.Mid(startPos, endPos - startPos + 1);
                        csTempSN.Trim();
                        csSNum = L"sheet" + csTempSN;
                    }
                }
            }
            
            int utilpos = line.Find(L"(UTILIZATION");
            if (utilpos != -1)
            {
                csUtil.Empty();
                csUtil = line.Mid(utilpos);
                csUtil.Replace(L"(UTILIZATION", L"");
                csUtil.Trim();

                if (!csSNum.IsEmpty())
                {
                    csFstr += L"SheetName: " + csSNum + L"\n";
                   cGV.vSnVals.push_back(csSNum);
                }
                if (!csUtil.IsEmpty())
                {
                    csUtil.Remove(L')');
                    csFstr += L"Utilization: " + csUtil + L"\n";
                    cGV.vUtVals.push_back(csUtil);
                }
                line.TrimLeft();
                isInSheet = false;
            }
            size_t partListPos = line.Find(L"(PARTLIST");
            if (partListPos != -1)
            {
                isInPartList = true;
                continue;
            }
            if (isInPartList)
            {
                size_t partPos = line.Find(L"(PART");
                if (partPos != -1)
                {
                    CString csPtLn = line;
                    bool foundInstances = false;
                    while (file1.ReadString(line))
                    {
                        csPtLn += L"\n" + line;
                        int instpos = line.Find(L"(INSTANCES");
                        if (instpos != -1)
                        {
                            int namePos = csPtLn.Find(L"(NAME");
                            if (namePos != -1)
                            {
                                int nameStart = csPtLn.Find(L"part");
                                int nameEnd = csPtLn.Find(L".prf");
                                if (nameStart != -1 && nameEnd != -1)
                                {
                                    CString partName = csPtLn.Mid(nameStart, nameEnd - nameStart + 4);
                                    partName.Replace(L".prf", L"");
                                    CString csInstVal;
                                    CString instStr = line.Mid(instpos);
                                    std::wstring instWStr(instStr);
                                    int tempInstancesValue;
                                    if (swscanf_s(instWStr.c_str(), L"(INSTANCES %d)", &tempInstancesValue) == 1)
                                    {
                                        csInstVal.Format(L"%d", tempInstancesValue);
                                        csInstVal.Remove(L')');
                                        OutArr[nR][0] = partName;
                                        OutArr[nR][1] = csInstVal;
                                        nR++;
                                    }
                                }
                                foundInstances = true;
                                break;
                            }
                        }
                        nR++;
                    }
                }
            }
        }
        file1.Close();
        CString editBoxText;
        for (size_t i = 0; i < cGV.vSnVals.size(); ++i)
        {
            editBoxText += L"Name: " + cGV.vSnVals[i]+L" ,";
            editBoxText += L"Utilization: " + cGV.vUtVals[i] + L"\r\n";
        }
        csText = editBoxText;
        m_EditBox.SetWindowText(csText);
    }

    //------------------------------------------

    std::vector<CString> partNames;
    for (int i = 0; i < nR; ++i)
    {
        CString partName = OutArr[i][0];
        partNames.push_back(partName);
    }
    sort(partNames.begin(), partNames.end());
    nRow = 0;
    for (int i = 0; i < nR; ++i)
    {
        CString partName = PtsArr[i][0];
        std::vector<CString> csInst;
        for (int j = 0; j < nR; ++j)
        {
            if (OutArr[j][0] == partName)
            {
                csInst.push_back(OutArr[j][1]);
            }
        }
        csInst.erase(remove_if(csInst.begin(), csInst.end(), [](const CString instance)
            {
                return instance.IsEmpty();
            }), csInst.end());

        sort(csInst.begin(), csInst.end());
        csInst.erase(unique(csInst.begin(), csInst.end()), csInst.end());
        //----------------------------

        for (const CString instance : csInst)
        {
            cGV.g_nestedQtyValues.push_back(instance);
        }
        int row = -1;
        for (int k = 0; k < nR; ++k)
        {
            if (PtsArr[k][0] == partName)
            {
                row = k;
                break;
            }
        }
        if (row != -1)
        {
            int nRow = 0;
            for (const CString instance : csInst)
            {
                m_ListCtrl.SetItemText(row + nRow, 4, instance);
                nRow++;
            }
        }
    }   
    return TRUE;
}


void CIrxSampleDialog::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_LIST1, m_ListCtrl);
    DDX_Text(pDX, IDC_EDIT1, csText);
}


BEGIN_MESSAGE_MAP(CIrxSampleDialog, CDialog)
    ON_BN_CLICKED(IDOK, OnBnClickedOk)
    ON_BN_CLICKED(IDCANCEL, OnBnClickedCancel)
    ON_NOTIFY(NM_CLICK, IDC_LIST1, &CIrxSampleDialog::OnNMClickList1)
END_MESSAGE_MAP()


void CIrxSampleDialog::OnBnClickedOk()
{
    OnOK();
}

void CIrxSampleDialog::OnBnClickedCancel()
{
    OnCancel();
}


void CIrxSampleDialog::OnNMClickList1(NMHDR* pNMHDR, LRESULT* pResult)
{
    Invalidate(1);
    
    HWND hWnd1 = ::GetDlgItem(m_hWnd, IDC_LIST1);
    LPNMITEMACTIVATE temp = (LPNMITEMACTIVATE)pNMHDR;
    RECT rect;

    nItem = temp->iItem;
    nSubItem = temp->iSubItem;
    if (nSubItem == -1 || nItem == -1)
        return;
    CString str = m_ListCtrl.GetItemText(nItem, nSubItem);
    ListView_GetSubItemRect(hWnd1, temp->iItem, temp->iSubItem, LVIR_BOUNDS, &rect);

    *pResult = 0;
}