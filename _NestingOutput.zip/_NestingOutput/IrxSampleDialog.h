#pragma once


// CIrxSampleDialog dialog
#include <vector>
#include "resource.h"
class CIrxSampleDialog : public CDialog
{
    DECLARE_DYNAMIC(CIrxSampleDialog)

public:
    CIrxSampleDialog(CWnd* pParent = NULL);
    virtual ~CIrxSampleDialog();

    // Dialog Data
    enum { IDD = IDD_DIALOG1 };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);


    CEdit m_EditBox;
    DECLARE_MESSAGE_MAP()

public:
    afx_msg void OnBnClickedOk();
    afx_msg void OnBnClickedCancel();
    afx_msg void OnNMClickList1(NMHDR* pNMHDR, LRESULT* pResult);

    virtual BOOL OnInitDialog();
    CString csSno, csPart, csCount;
    CListCtrl m_ListCtrl;
    int nRow, nSubItem, nItem;
    CString csText;
    
    CString PtsArr[1000][2];
    CString OutArr[1000][2];
};