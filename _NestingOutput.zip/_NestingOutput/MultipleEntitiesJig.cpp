#include "stdafx.h"
#include "MultipleEntitiesJig.h"

namespace IcJigSamples
{
	IcMultipleEntitiesJig::IcMultipleEntitiesJig(OdDbDatabasePtr database) : m_Database(database)
	{
		m_DrawList = IcEdObjectsListDrawable::createListObject();
	}

	IcEdJig::DragStatus IcMultipleEntitiesJig::dragIt()
	{
		// Create line A
		m_LineA = OdDbLine::createObject();
		m_LineA->setDatabaseDefaults(m_Database);
		m_LineA->setNormal(OdGeVector3d::kZAxis);

		OdGePoint3d startPointA(0.0, 0.0, 0);
		OdGePoint3d endPoint(10.0, 10.0, 0);
		m_LineA->setStartPoint(startPointA);
		m_LineA->setEndPoint(endPoint);

		m_LineB = OdDbLine::createObject();
		m_LineB->setDatabaseDefaults(m_Database);
		m_LineB->setNormal(OdGeVector3d::kZAxis);

		// Create line B
		OdGePoint3d startPointB(20.0, 0.0, 0);
		m_LineB->setStartPoint(startPointB);
		m_LineB->setEndPoint(endPoint);

		// Create circle
		m_Circle = OdDbCircle::createObject();
		m_Circle->setDatabaseDefaults(m_Database);
		m_Circle->setNormal(OdGeVector3d::kZAxis);

		m_Circle->setRadius(1.0);
		m_Circle->setCenter(endPoint);

		// Adding entities to the list
		m_DrawList->clear();
		m_DrawList->append(m_LineA);
		m_DrawList->append(m_LineB);
		m_DrawList->append(m_Circle);

		m_CurrentPointIsEmpty = true;

		return drag();
	}

	IcEdJig::DragStatus IcMultipleEntitiesJig::sampler()
	{
		OdGePoint3d currentPoint;
		IcEdJig::DragStatus status = acquirePoint(currentPoint);

		if (status == IcEdJig::kNormal)
		{
			if (!m_CurrentPointIsEmpty && currentPoint.isEqualTo(m_CurrentPoint))
			{
				return IcEdJig::kNoChange;
			}
			else
			{
				m_CurrentPoint = currentPoint;
				m_CurrentPointIsEmpty = false;
			}
		}

		return IcEdJig::kNormal;
	}

	bool IcMultipleEntitiesJig::update()
	{
		bool doUpdate(false);

		if (!m_CurrentPointIsEmpty)
		{
			m_LineA->setEndPoint(m_CurrentPoint);
			m_LineB->setEndPoint(m_CurrentPoint);
			m_Circle->setCenter(m_CurrentPoint);

			doUpdate = true;
		}

		return doUpdate;
	}

	OdDbEntity* IcMultipleEntitiesJig::entity() const
	{
		return nullptr;
	}

	const IcEdObjectsListDrawable* IcMultipleEntitiesJig::entities() const
	{
		return m_DrawList.get();
	}

	void jigMultpleEntitiesCommand(OdEdCommandContext* pCmdCtx)
	{
		IcMultipleEntitiesJig jig(pCmdCtx->baseDatabase());

		IcEdJig::DragStatus status = jig.dragIt();

		if(status != IcEdJig::kNormal && status != IcEdJig::kCancel)
		{
			throw OdError(eInvalidInput);
		}
	}
}