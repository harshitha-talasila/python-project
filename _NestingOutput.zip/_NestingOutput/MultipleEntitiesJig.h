#pragma once

#include "../../inc/IcEdJig.h"
#include "DbDatabase.h"
#include "DbLine.h"
#include "DbCircle.h"
#include "IcEdObjectsListDrawable.h"
#include "Ed/EdCommandContext.h"

namespace IcJigSamples
{
	void jigMultpleEntitiesCommand(OdEdCommandContext* pCmdCtx);

	class IcMultipleEntitiesJig : IcEdJig
	{
	public:
		IcMultipleEntitiesJig(OdDbDatabasePtr database);

		virtual ~IcMultipleEntitiesJig() = default;

		IcEdJig::DragStatus dragIt();

	protected:
		virtual IcEdJig::DragStatus sampler();

		virtual bool update();

		virtual OdDbEntity* entity() const;

		virtual const IcEdObjectsListDrawable* entities() const;

	private:
		OdDbDatabasePtr m_Database;
		IcEdObjectsListDrawablePtr m_DrawList;

		OdDbLinePtr m_LineA;
		OdDbLinePtr m_LineB;
		OdDbCirclePtr m_Circle;

		OdGePoint3d m_CurrentPoint;
		bool m_CurrentPointIsEmpty = true;
	};
}