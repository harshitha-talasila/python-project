//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by IRXSample.rc
//
#define IDC_EDIT1                       3001
#define IDC_SHOWPREVIEW                 3002
#define IDC_RICHEDIT21                  3003
#define IDD_DIALOG1                     3004
#define IDD_DIALOG2                     3005
#define IDB_ACTCAD_LOGO                 3006
#define IDI_ICON1                       3007
#define IDC_LIST1                       3007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        3006
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         3008
#define _APS_NEXT_SYMED_VALUE           3001
#endif
#endif
